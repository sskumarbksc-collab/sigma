from engine import TradingEngine

eng = TradingEngine()
eng.watchlist = eng.watchlist[:35]
print("Scanning 35 stocks for Narrow CPR, Gamma Blast, and FVG...", flush=True)
res = eng.run_full_scan()

strats = res['smc_strategies']

print("\n================== 1. NARROW CPR TREND BLAST ==================")
cpr_list = strats.get('strategy_cpr_blast', [])
print(f"Total Found: {len(cpr_list)}")
for s in cpr_list:
    sym = s.get('symbol')
    action = s.get('action')
    entry = s.get('entry')
    sl = s.get('stop_loss')
    tgt = s.get('target')
    rr = s.get('risk_reward')
    rat = s.get('rationale')
    print(f"{sym} | {action} | Entry: {entry} | SL: {sl} | Tgt: {tgt} | RR: {rr}")
    print(f"  Rationale: {rat}")

print("\n================== 2. OPTION SELLER TRAP / GAMMA BLAST ========")
gamma_list = strats.get('strategy_gamma_blast', [])
print(f"Total Found: {len(gamma_list)}")
for s in gamma_list:
    sym = s.get('symbol')
    action = s.get('action')
    entry = s.get('entry')
    sl = s.get('stop_loss')
    tgt = s.get('target')
    rr = s.get('risk_reward')
    rat = s.get('rationale')
    print(f"{sym} | {action} | Entry: {entry} | SL: {sl} | Tgt: {tgt} | RR: {rr}")
    print(f"  Rationale: {rat}")

print("\n================== 3. FAIR VALUE GAP (FVG / IMBALANCE) ========")
fvg_list = strats.get('strategy_fvg', [])
print(f"Total Found: {len(fvg_list)}")
for s in fvg_list[:5]:
    sym = s.get('symbol')
    action = s.get('action')
    entry = s.get('entry')
    sl = s.get('stop_loss')
    tgt = s.get('target')
    rr = s.get('risk_reward')
    rat = s.get('rationale')
    print(f"{sym} | {action} | Entry: {entry} | SL: {sl} | Tgt: {tgt} | RR: {rr}")
    print(f"  Rationale: {rat}")
