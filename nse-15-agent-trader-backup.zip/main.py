import asyncio
import os
from contextlib import asynccontextmanager
from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from config import BASE_DIR, UPSTOX_CONFIG
from engine import TradingEngine

# Initialize orchestrator engine
engine = TradingEngine()
background_task_handle = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Perform initial scan on startup
    logger = engine.data_feed.get_market_pulse()
    print("Initializing 15-AI-Agent NSE Trading System...")
    # Run initial scan in background thread so server starts promptly
    asyncio.create_task(asyncio.to_thread(engine.run_full_scan))
    yield
    engine.auto_scan_active = False

app = FastAPI(
    title="NSE 15-AI-Agent Trading Terminal",
    description="Multi-agent institutional setup generator for Intraday & F&O",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
static_dir = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir, exist_ok=True)

app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def read_root():
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "NSE 15-Agent Trading Terminal Backend is running."}

@app.get("/api/status")
def get_status():
    return {
        "status": "ONLINE",
        "is_scanning": engine.is_scanning,
        "auto_scan_active": engine.auto_scan_active,
        "last_scan_time": engine.last_scan_time,
        "active_setups_count": len(engine.active_setups),
        "approved_count": sum(1 for s in engine.active_setups if s.get("status") == "APPROVED"),
        "watchlist_size": len(engine.watchlist)
    }

@app.get("/api/pulse")
def get_market_pulse():
    pulse = engine.market_pulse or engine.data_feed.get_market_pulse()
    return pulse

@app.get("/api/setups")
def get_setups(filter_approved_only: bool = False):
    setups = engine.active_setups
    if filter_approved_only:
        setups = [s for s in setups if s.get("status") == "APPROVED"]
    return {
        "count": len(setups),
        "last_scan": engine.last_scan_time,
        "setups": setups
    }

@app.get("/api/agents")
def get_agents():
    return {
        "total_agents": 15,
        "agents": engine.get_agent_states()
    }

@app.get("/api/smc-strategies")
def get_smc_strategies():
    return engine.get_smc_strategy_setups()

@app.post("/api/scan")
async def trigger_scan(background_tasks: BackgroundTasks):
    if engine.is_scanning:
        return {"status": "ALREADY_SCANNING", "message": "A scan is already in progress."}
    background_tasks.add_task(engine.run_full_scan)
    return {"status": "STARTED", "message": "15-Agent scan triggered across NSE watchlist."}

@app.get("/api/logs")
def get_logs():
    return {
        "logs": engine.scan_logs
    }

class UpstoxConfigModel(BaseModel):
    api_key: Optional[str] = ""
    api_secret: Optional[str] = ""
    access_token: Optional[str] = ""

@app.get("/api/upstox/config")
def get_upstox_config():
    # Mask secrets
    token = UPSTOX_CONFIG.get("access_token", "")
    masked_token = f"{token[:6]}...{token[-4:]}" if len(token) > 10 else ("Configured" if token else "Not Configured")
    return {
        "is_connected": bool(token),
        "api_key": UPSTOX_CONFIG.get("api_key", ""),
        "access_token_status": masked_token,
        "redirect_uri": UPSTOX_CONFIG.get("redirect_uri", "")
    }

@app.post("/api/upstox/config")
def save_upstox_config(cfg: UpstoxConfigModel):
    if cfg.api_key:
        UPSTOX_CONFIG["api_key"] = cfg.api_key
    if cfg.api_secret:
        UPSTOX_CONFIG["api_secret"] = cfg.api_secret
    if cfg.access_token:
        UPSTOX_CONFIG["access_token"] = cfg.access_token
    return {
        "status": "SUCCESS",
        "message": "Upstox configuration updated successfully.",
        "is_connected": bool(UPSTOX_CONFIG.get("access_token"))
    }

class SettingsModel(BaseModel):
    scan_interval: Optional[int] = None
    watchlist: Optional[List[str]] = None
    auto_scan: Optional[bool] = None

@app.post("/api/settings")
def update_settings(settings: SettingsModel):
    if settings.scan_interval:
        engine.scan_interval = max(15, settings.scan_interval)
    if settings.watchlist:
        engine.watchlist = settings.watchlist
    if settings.auto_scan is not None:
        engine.auto_scan_active = settings.auto_scan
        if engine.auto_scan_active:
            asyncio.create_task(engine.background_scan_loop())
    return {
        "status": "UPDATED",
        "scan_interval": engine.scan_interval,
        "auto_scan_active": engine.auto_scan_active,
        "watchlist": engine.watchlist
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
