import asyncio
import os
import json
from contextlib import asynccontextmanager
from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

from config import BASE_DIR, UPSTOX_CONFIG
from engine import TradingEngine

# Initialize orchestrator engine
engine = TradingEngine()
background_task_handle = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Perform initial scan on startup
    logger = engine.data_feed.get_market_pulse()
    print("Initializing 15-AI-Agent NSE Trading System...")
    # Run initial scan in background thread so server starts promptly
    asyncio.create_task(asyncio.to_thread(engine.run_full_scan))
    yield
    engine.auto_scan_active = False

app = FastAPI(
    title="NSE 15-AI-Agent Trading Terminal",
    description="Multi-agent institutional setup generator for Intraday & F&O",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files
static_dir = os.path.join(BASE_DIR, "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir, exist_ok=True)

app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def read_root():
    index_path = os.path.join(static_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "NSE 15-Agent Trading Terminal Backend is running."}

@app.get("/api/status")
def get_status():
    return {
        "status": "ONLINE",
        "is_scanning": engine.is_scanning,
        "auto_scan_active": engine.auto_scan_active,
        "last_scan_time": engine.last_scan_time,
        "active_setups_count": len(engine.active_setups),
        "approved_count": sum(1 for s in engine.active_setups if s.get("status") == "APPROVED"),
        "watchlist_size": len(engine.watchlist)
    }

@app.get("/api/pulse")
def get_market_pulse():
    pulse = engine.market_pulse or engine.data_feed.get_market_pulse()
    return pulse

@app.get("/api/setups")
def get_setups(filter_approved_only: bool = False):
    setups = engine.active_setups
    if filter_approved_only:
        setups = [s for s in setups if s.get("status") == "APPROVED"]
    return {
        "count": len(setups),
        "last_scan": engine.last_scan_time,
        "setups": setups
    }

@app.get("/api/agents")
def get_agents():
    return {
        "total_agents": 15,
        "agents": engine.get_agent_states()
    }

@app.get("/api/smc-strategies")
def get_smc_strategies():
    return engine.get_smc_strategy_setups()

@app.get("/api/backtest")
def get_backtest_report(timeframe: Optional[str] = None):
    return engine.get_backtest_report(timeframe=timeframe)

class TimeframeModel(BaseModel):
    timeframe: str

@app.post("/api/timeframe")
async def set_timeframe(model: TimeframeModel, background_tasks: BackgroundTasks):
    tf = model.timeframe.lower()
    if tf not in ["5m", "15m"]:
        raise HTTPException(status_code=400, detail="Timeframe must be '5m' or '15m'")
    engine.current_timeframe = tf
    background_tasks.add_task(engine.run_full_scan, tf)
    return {"status": "SUCCESS", "current_timeframe": engine.current_timeframe.upper()}

@app.post("/api/scan")
async def trigger_scan(background_tasks: BackgroundTasks):
    if engine.is_scanning:
        return {"status": "ALREADY_SCANNING", "message": "A scan is already in progress."}
    background_tasks.add_task(engine.run_full_scan, engine.current_timeframe)
    return {"status": "STARTED", "message": f"Scan triggered on {engine.current_timeframe.upper()} across NSE watchlist."}

@app.get("/api/logs")
def get_logs():
    return {
        "logs": engine.scan_logs
    }

class UpstoxConfigModel(BaseModel):
    api_key: Optional[str] = ""
    api_secret: Optional[str] = ""
    access_token: Optional[str] = ""

@app.get("/api/upstox/config")
def get_upstox_config():
    # Mask secrets
    token = UPSTOX_CONFIG.get("access_token", "")
    masked_token = f"{token[:6]}...{token[-4:]}" if len(token) > 10 else ("Configured" if token else "Not Configured")
    return {
        "is_connected": bool(token),
        "api_key": UPSTOX_CONFIG.get("api_key", ""),
        "access_token_status": masked_token,
        "redirect_uri": UPSTOX_CONFIG.get("redirect_uri", "")
    }

@app.post("/api/upstox/config")
def save_upstox_config(cfg: UpstoxConfigModel):
    if cfg.api_key:
        UPSTOX_CONFIG["api_key"] = cfg.api_key
    if cfg.api_secret:
        UPSTOX_CONFIG["api_secret"] = cfg.api_secret
    if cfg.access_token:
        UPSTOX_CONFIG["access_token"] = cfg.access_token
    return {
        "status": "SUCCESS",
        "message": "Upstox configuration updated successfully.",
        "is_connected": bool(UPSTOX_CONFIG.get("access_token"))
    }

class SettingsModel(BaseModel):
    scan_interval: Optional[int] = None
    watchlist: Optional[List[str]] = None
    auto_scan: Optional[bool] = None

@app.post("/api/settings")
def update_settings(settings: SettingsModel):
    if settings.scan_interval:
        engine.scan_interval = max(15, settings.scan_interval)
    if settings.watchlist:
        engine.watchlist = settings.watchlist
    if settings.auto_scan is not None:
        engine.auto_scan_active = settings.auto_scan
        if engine.auto_scan_active:
            asyncio.create_task(engine.background_scan_loop())
    return {
        "status": "UPDATED",
        "scan_interval": engine.scan_interval,
        "auto_scan_active": engine.auto_scan_active,
        "watchlist": engine.watchlist
    }

# ==================== ALL 2605 NSE STOCKS SEARCH & ANALYZE API ====================
ALL_STOCKS_DB = []
try:
    all_stocks_path = os.path.join(BASE_DIR, "nse_all_stocks.json")
    if os.path.exists(all_stocks_path):
        with open(all_stocks_path, "r", encoding="utf-8") as f:
            ALL_STOCKS_DB = json.load(f)
except Exception as e:
    print(f"Error loading stock database: {e}")

@app.get("/api/stocks/all")
def get_all_stocks_count():
    return {
        "total_listed_stocks": len(ALL_STOCKS_DB),
        "pools_available": ["NIFTY_500", "ALL_NSE_2600", "NSE_FNO_80", "NIFTY_50", "TOP_15"]
    }

@app.get("/api/stocks/search")
def search_stocks(q: str = ""):
    query = q.strip().upper()
    if not query:
        return {"results": []}
    matches = []
    for item in ALL_STOCKS_DB:
        code = item.get("code", "")
        name = item.get("name", "")
        if query in code or query in name.upper():
            matches.append(item)
            if len(matches) >= 30:
                break
    return {"query": query, "count": len(matches), "results": matches}

class AnalyzeStockModel(BaseModel):
    symbol: str

@app.post("/api/stocks/analyze")
def analyze_single_stock(model: AnalyzeStockModel):
    sym = model.symbol.strip().upper()
    if not sym.endswith(".NS") and not sym.startswith("^"):
        sym = f"{sym}.NS"
    ticket = engine.scan_single_symbol(sym, engine.market_pulse, timeframe=engine.current_timeframe)
    if not ticket:
        raise HTTPException(status_code=404, detail=f"Stock data not available for symbol '{sym}'")
    return {"status": "SUCCESS", "ticket": ticket}

class WatchlistActionModel(BaseModel):
    symbol: str

@app.post("/api/watchlist/add")
def add_to_watchlist(model: WatchlistActionModel):
    sym = model.symbol.strip().upper()
    if not sym.endswith(".NS") and not sym.startswith("^"):
        sym = f"{sym}.NS"
    if sym not in engine.watchlist:
        engine.watchlist.insert(0, sym)
    return {"status": "SUCCESS", "message": f"{sym} added to active scanner.", "watchlist_count": len(engine.watchlist)}

class WatchlistPoolModel(BaseModel):
    pool: str

@app.get("/api/watchlist")
def get_watchlist():
    return engine.get_watchlist_status()

@app.post("/api/watchlist/pool")
async def switch_watchlist_pool(model: WatchlistPoolModel, background_tasks: BackgroundTasks):
    res = engine.set_watchlist_pool(model.pool)
    if res.get("status") == "SUCCESS":
        background_tasks.add_task(engine.run_full_scan, engine.current_timeframe)
        return res
    raise HTTPException(status_code=400, detail="Invalid watchlist pool. Choose 'ALL_NSE_2600', 'NIFTY_500', 'NSE_FNO_80', 'NIFTY_50', or 'TOP_15'")


# ==================== AUTO-TRADER (UPSTOX & ₹20,000 CAPITAL) ENDPOINTS ====================
class AutoTradeConfigModel(BaseModel):
    is_auto_trade_enabled: Optional[bool] = None
    mode: Optional[str] = None  # 'PAPER' or 'LIVE'
    total_capital: Optional[float] = None
    risk_per_trade_pct: Optional[float] = None
    max_daily_loss: Optional[float] = None
    min_consensus_required: Optional[float] = None

@app.get("/api/autotrade")
def get_autotrade_state():
    return engine.auto_trader.get_all_trades()

@app.post("/api/autotrade/config")
def set_autotrade_config(cfg: AutoTradeConfigModel):
    payload = {}
    if cfg.is_auto_trade_enabled is not None:
        payload["is_auto_trade_enabled"] = cfg.is_auto_trade_enabled
    if cfg.mode is not None:
        payload["mode"] = cfg.mode.upper()
    if cfg.total_capital is not None:
        payload["total_capital"] = cfg.total_capital
    if cfg.risk_per_trade_pct is not None:
        payload["risk_per_trade_pct"] = cfg.risk_per_trade_pct
    if cfg.max_daily_loss is not None:
        payload["max_daily_loss"] = cfg.max_daily_loss
    if cfg.min_consensus_required is not None:
        payload["min_consensus_required"] = cfg.min_consensus_required

    updated_status = engine.auto_trader.update_config(payload)
    return {
        "status": "SUCCESS",
        "message": "Auto-trader settings updated successfully.",
        "config": updated_status
    }

@app.post("/api/autotrade/toggle")
def toggle_autotrade():
    engine.auto_trader.is_auto_trade_enabled = not engine.auto_trader.is_auto_trade_enabled
    return {
        "status": "SUCCESS",
        "is_auto_trade_enabled": engine.auto_trader.is_auto_trade_enabled,
        "mode": engine.auto_trader.mode
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
