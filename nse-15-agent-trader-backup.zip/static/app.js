// NSE 15-AI-Agent Trading Terminal Frontend Engine
let allSetups = [];
let currentFilter = 'ALL';
let isAudioEnabled = true;
let isAutoScanRunning = false;
let audioCtx = null;

// Initialize Web Audio Context on user interaction
function getAudioContext() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    return audioCtx;
}

// Play modern futuristic chime for approved high-conviction setup
function playTradeAlertChime() {
    if (!isAudioEnabled) return;
    try {
        const ctx = getAudioContext();
        const now = ctx.currentTime;
        
        // Two-tone pleasant institutional notification chime (E5 -> B5)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(659.25, now); // E5
        osc1.frequency.setValueAtTime(987.77, now + 0.12); // B5
        
        gain1.gain.setValueAtTime(0.01, now);
        gain1.gain.linearRampToValueAtTime(0.2, now + 0.05);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        
        osc1.start(now);
        osc1.stop(now + 0.5);
    } catch (e) {
        console.warn('Audio chime notice:', e);
    }
}

// DOM Elements
const niftyLtp = document.getElementById('niftyLtp');
const niftyChange = document.getElementById('niftyChange');
const bnLtp = document.getElementById('bnLtp');
const bnChange = document.getElementById('bnChange');
const vixVal = document.getElementById('vixVal');
const vixRegime = document.getElementById('vixRegime');
const breadthRatio = document.getElementById('breadthRatio');
const breadthSentiment = document.getElementById('breadthSentiment');
const lastScanTime = document.getElementById('lastScanTime');
const setupsGrid = document.getElementById('setupsGrid');
const setupCountBadge = document.getElementById('setupCountBadge');
const agentsMatrixGrid = document.getElementById('agentsMatrixGrid');
const scannerTableBody = document.getElementById('scannerTableBody');
const terminalLogs = document.getElementById('terminalLogs');

const btnRunScan = document.getElementById('btnRunScan');
const btnAutoScanToggle = document.getElementById('btnAutoScanToggle');
const autoScanText = document.getElementById('autoScanText');
const btnAudioToggle = document.getElementById('btnAudioToggle');
const audioIcon = document.getElementById('audioIcon');
const systemStatusText = document.getElementById('systemStatusText');

// Setup Inspector Modal
const setupInspectorModal = document.getElementById('setupInspectorModal');
const closeInspectorBtn = document.getElementById('closeInspectorBtn');
const modalSymbolTitle = document.getElementById('modalSymbolTitle');
const modalActionBadge = document.getElementById('modalActionBadge');
const modalInstrument = document.getElementById('modalInstrument');
const modalEntry = document.getElementById('modalEntry');
const modalStopLoss = document.getElementById('modalStopLoss');
const modalTarget1 = document.getElementById('modalTarget1');
const modalTarget2 = document.getElementById('modalTarget2');
const modalRiskReward = document.getElementById('modalRiskReward');
const modalConsensus = document.getElementById('modalConsensus');
const modalMasterThesis = document.getElementById('modalMasterThesis');
const modalAgentVotesList = document.getElementById('modalAgentVotesList');

// Upstox Modal
const upstoxModal = document.getElementById('upstoxModal');
const btnUpstoxModal = document.getElementById('btnUpstoxModal');
const closeUpstoxBtn = document.getElementById('closeUpstoxBtn');
const btnCancelUpstox = document.getElementById('btnCancelUpstox');
const btnSaveUpstox = document.getElementById('btnSaveUpstox');
const upstoxApiKey = document.getElementById('upstoxApiKey');
const upstoxApiSecret = document.getElementById('upstoxApiSecret');
const upstoxAccessToken = document.getElementById('upstoxAccessToken');
const upstoxConnStatus = document.getElementById('upstoxConnStatus');

// 1. Fetch Market Pulse
async function fetchMarketPulse() {
    try {
        const res = await fetch('/api/pulse');
        const data = await res.json();
        
        // Nifty 50
        const n = data.nifty50 || {};
        niftyLtp.innerText = `₹${n.ltp?.toLocaleString('en-IN') || '--'}`;
        const nSign = n.change_pct >= 0 ? '+' : '';
        niftyChange.innerText = `${nSign}${n.change_pct || 0}%`;
        niftyChange.className = `pulse-change ${n.change_pct >= 0 ? 'bullish' : 'bearish'}`;

        // Bank Nifty
        const bn = data.banknifty || {};
        bnLtp.innerText = `₹${bn.ltp?.toLocaleString('en-IN') || '--'}`;
        const bnSign = bn.change_pct >= 0 ? '+' : '';
        bnChange.innerText = `${bnSign}${bn.change_pct || 0}%`;
        bnChange.className = `pulse-change ${bn.change_pct >= 0 ? 'bullish' : 'bearish'}`;

        // India VIX
        const v = data.india_vix || {};
        vixVal.innerText = v.value || '--';
        vixRegime.innerText = v.regime || 'NORMAL';

        // Breadth
        const b = data.market_breadth || {};
        breadthRatio.innerText = `${b.advances || 0}A / ${b.declines || 0}D (${b.ratio || 1.0}x)`;
        breadthSentiment.innerText = b.sentiment || 'BALANCED';
        breadthSentiment.className = `pulse-tag ${(b.sentiment || '').includes('BULL') ? 'text-green' : 'text-red'}`;

    } catch (e) {
        console.error('Error fetching market pulse:', e);
    }
}

// 2. Fetch Setups
async function fetchSetups() {
    try {
        const res = await fetch('/api/setups');
        const data = await res.json();
        allSetups = data.setups || [];
        lastScanTime.innerText = data.last_scan || '--:--:--';
        
        renderSetups();
        renderScannerTable();
    } catch (e) {
        console.error('Error fetching setups:', e);
    }
}

// Render Setup Cards
function renderSetups() {
    let filtered = allSetups;
    if (currentFilter === 'APPROVED') {
        filtered = allSetups.filter(s => s.status === 'APPROVED');
    } else if (currentFilter === 'BULLISH') {
        filtered = allSetups.filter(s => s.direction === 'BULLISH');
    } else if (currentFilter === 'BEARISH') {
        filtered = allSetups.filter(s => s.direction === 'BEARISH');
    }

    const approvedCount = allSetups.filter(s => s.status === 'APPROVED').length;
    setupCountBadge.innerText = `${approvedCount} APPROVED`;

    if (filtered.length === 0) {
        setupsGrid.innerHTML = `
            <div class="loading-state">
                <i class="fa-solid fa-filter fa-2x text-muted" style="margin-bottom: 12px;"></i>
                <p>No setups matching filter "${currentFilter}".</p>
                <small class="text-muted">Click "SCAN NOW" or wait for next automatic sweep cycle.</small>
            </div>
        `;
        return;
    }

    setupsGrid.innerHTML = filtered.map((s, idx) => {
        const isApproved = s.status === 'APPROVED';
        const isBullish = s.direction === 'BULLISH';
        const isBearish = s.direction === 'BEARISH';
        const cardClass = isApproved ? (isBearish ? 'card-approved bearish' : 'card-approved') : '';
        const pillClass = isBullish ? 'bullish' : (isBearish ? 'bearish' : 'neutral');
        const fillClass = isBullish ? 'fill-green' : (isBearish ? 'fill-red' : 'fill-yellow');

        return `
            <div class="setup-card ${cardClass}" onclick="openSetupInspector(${idx})">
                <div class="card-top">
                    <div class="symbol-group">
                        <span class="symbol-name">${s.symbol}</span>
                        <span class="instrument-name">${s.instrument}</span>
                    </div>
                    <span class="action-pill ${pillClass}">
                        ${isBullish ? '<i class="fa-solid fa-arrow-trend-up"></i>' : (isBearish ? '<i class="fa-solid fa-arrow-trend-down"></i>' : '<i class="fa-solid fa-minus"></i>')}
                        ${s.action}
                    </span>
                </div>

                <div class="levels-grid">
                    <div class="level-box">
                        <span class="level-title">ENTRY ZONE</span>
                        <span class="level-num text-cyan">₹${s.entry}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">STOP LOSS</span>
                        <span class="level-num text-red">₹${s.stop_loss}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">TARGET 1</span>
                        <span class="level-num text-green">₹${s.target1}</span>
                    </div>
                </div>

                <div class="consensus-wrapper">
                    <div class="consensus-header">
                        <span>15-AGENT CONSENSUS</span>
                        <strong class="${isBullish ? 'text-green' : (isBearish ? 'text-red' : 'text-yellow')}">
                            ${s.consensus_pct}% (${s.bullish_votes}B / ${s.bearish_votes}S)
                        </strong>
                    </div>
                    <div class="consensus-progress-track">
                        <div class="consensus-progress-fill ${fillClass}" style="width: ${s.consensus_pct}%;"></div>
                    </div>
                </div>

                <div class="card-footer">
                    <span><i class="fa-solid fa-scale-balanced"></i> R:R ${s.risk_reward}</span>
                    <span class="${isApproved ? 'text-green' : 'text-muted'}">
                        ${isApproved ? '<i class="fa-solid fa-circle-check"></i> INSTITUTIONAL PASS' : '<i class="fa-solid fa-eye"></i> WATCHLIST'}
                    </span>
                    <span><i class="fa-regular fa-clock"></i> ${s.timestamp}</span>
                </div>
            </div>
        `;
    }).join('');
}

// 3. Render Watchlist Scanner Table
function renderScannerTable() {
    if (allSetups.length === 0) {
        scannerTableBody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No data scanned yet.</td></tr>`;
        return;
    }

    scannerTableBody.innerHTML = allSetups.map((s, idx) => {
        const isBull = s.direction === 'BULLISH';
        const isBear = s.direction === 'BEARISH';
        const pillClass = isBull ? 'bullish' : (isBear ? 'bearish' : 'neutral');

        return `
            <tr>
                <td><strong>${s.symbol}</strong></td>
                <td>₹${s.ltp}</td>
                <td class="${isBull ? 'text-green' : (isBear ? 'text-red' : 'text-muted')}">
                    ${isBull ? '+' : ''}${((s.entry - s.stop_loss) / s.entry * 100).toFixed(2)}%
                </td>
                <td><span class="action-pill ${pillClass}">${s.action}</span></td>
                <td>${s.instrument}</td>
                <td><strong class="${isBull ? 'text-green' : (isBear ? 'text-red' : 'text-yellow')}">${s.consensus_pct}%</strong></td>
                <td><small>${s.bullish_votes} Bull / ${s.bearish_votes} Bear / ${s.neutral_votes} Neu</small></td>
                <td>
                    <span class="badge ${s.status === 'APPROVED' ? 'badge-cyan' : ''}">
                        ${s.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-secondary btn-sm" onclick="openSetupInspector(${idx})">
                        <i class="fa-solid fa-magnifying-glass-chart"></i> Inspect
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// 4. Fetch 15 AI Agents Live Matrix
async function fetchAgents() {
    try {
        const res = await fetch('/api/agents');
        const data = await res.json();
        const agents = data.agents || [];

        agentsMatrixGrid.innerHTML = agents.map(a => {
            const verdict = a.last_verdict;
            const vote = verdict ? verdict.vote : 'IDLE';
            const voteClass = vote === 'BULLISH' ? 'text-green' : (vote === 'BEARISH' ? 'text-red' : 'text-yellow');
            const score = verdict ? verdict.score : 0.0;
            const rationale = verdict ? verdict.rationale : 'Awaiting next market candle evaluation cycle.';

            return `
                <div class="agent-matrix-card">
                    <div class="agent-card-header">
                        <div class="agent-title-row">
                            <span class="agent-badge-id">${a.agent_id}</span>
                            <div>
                                <div class="agent-name-text">${a.name}</div>
                                <div class="agent-layer-tag">${a.layer}</div>
                            </div>
                        </div>
                    </div>

                    <div class="agent-verdict-banner">
                        <span>VERDICT: <strong class="${voteClass}">${vote}</strong></span>
                        <span>CONFIDENCE: <strong>${verdict ? verdict.confidence + '%' : '--'}</strong></span>
                    </div>

                    <div class="agent-rationale-text">
                        ${rationale}
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) {
        console.error('Error fetching agents:', e);
    }
}

// 5. Fetch Logs
async function fetchLogs() {
    try {
        const res = await fetch('/api/logs');
        const data = await res.json();
        const logs = data.logs || [];
        if (logs.length > 0) {
            terminalLogs.innerHTML = logs.map(l => `<div class="log-line">${l}</div>`).join('');
            terminalLogs.scrollTop = terminalLogs.scrollHeight;
        }
    } catch (e) {
        console.error('Error fetching logs:', e);
    }
}

// Open Setup Inspector Modal (All 15 Agent Votes)
window.openSetupInspector = function(index) {
    const s = allSetups[index];
    if (!s) return;

    modalSymbolTitle.innerText = s.symbol;
    modalInstrument.innerText = s.instrument;
    modalActionBadge.innerText = s.action;
    modalActionBadge.className = `badge badge-outline ${s.direction === 'BULLISH' ? 'text-green' : (s.direction === 'BEARISH' ? 'text-red' : 'text-yellow')}`;

    modalEntry.innerText = `₹${s.entry}`;
    modalStopLoss.innerText = `₹${s.stop_loss}`;
    modalTarget1.innerText = `₹${s.target1}`;
    modalTarget2.innerText = `₹${s.target2}`;
    modalRiskReward.innerText = s.risk_reward;
    modalConsensus.innerText = `${s.consensus_pct}% (${s.bullish_votes}B / ${s.bearish_votes}S)`;

    modalMasterThesis.innerText = s.master_thesis || 'No rationale available.';

    // Populate individual 15 agent breakdowns
    const breakdown = s.agent_breakdown || [];
    modalAgentVotesList.innerHTML = breakdown.map(a => {
        const vClass = a.vote === 'BULLISH' ? 'text-green' : (a.vote === 'BEARISH' ? 'text-red' : 'text-yellow');
        return `
            <div class="vote-item">
                <div class="vote-header">
                    <span><strong>Agent ${a.agent_id}: ${a.name}</strong> (${a.role})</span>
                    <span class="${vClass}">${a.vote} (${a.confidence}%)</span>
                </div>
                <div class="vote-rationale">${a.rationale}</div>
            </div>
        `;
    }).join('');

    setupInspectorModal.classList.add('open');
};

// Close modals
closeInspectorBtn.addEventListener('click', () => setupInspectorModal.classList.remove('open'));
setupInspectorModal.addEventListener('click', (e) => {
    if (e.target === setupInspectorModal) setupInspectorModal.classList.remove('open');
});

btnUpstoxModal.addEventListener('click', async () => {
    try {
        const res = await fetch('/api/upstox/config');
        const data = await res.json();
        upstoxApiKey.value = data.api_key || '';
        upstoxConnStatus.innerText = data.is_connected ? 'Connected (Live Broker Feed)' : 'Not Connected (Using Open Data)';
        upstoxConnStatus.className = data.is_connected ? 'text-green' : 'text-yellow';
    } catch (e) {}
    upstoxModal.classList.add('open');
});

closeUpstoxBtn.addEventListener('click', () => upstoxModal.classList.remove('open'));
btnCancelUpstox.addEventListener('click', () => upstoxModal.classList.remove('open'));

btnSaveUpstox.addEventListener('click', async () => {
    const payload = {
        api_key: upstoxApiKey.value.trim(),
        api_secret: upstoxApiSecret.value.trim(),
        access_token: upstoxAccessToken.value.trim()
    };
    try {
        const res = await fetch('/api/upstox/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        alert(data.message || 'Saved!');
        upstoxModal.classList.remove('open');
    } catch (e) {
        alert('Failed to save Upstox configuration.');
    }
});

// Run Scan Button
btnRunScan.addEventListener('click', async () => {
    btnRunScan.disabled = true;
    btnRunScan.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> <span>SCANNING...</span>';
    systemStatusText.innerText = '15 AGENTS SCANNING...';

    try {
        await fetch('/api/scan', { method: 'POST' });
        // Poll status until scan finishes
        const poll = setInterval(async () => {
            const statusRes = await fetch('/api/status');
            const statusData = await statusRes.json();
            if (!statusData.is_scanning) {
                clearInterval(poll);
                btnRunScan.disabled = false;
                btnRunScan.innerHTML = '<i class="fa-solid fa-bolt"></i> <span>SCAN NOW</span>';
                systemStatusText.innerText = 'SYSTEM READY';
                await fetchSetups();
                await fetchAgents();
                await fetchLogs();
                playTradeAlertChime();
            }
        }, 2000);
    } catch (e) {
        btnRunScan.disabled = false;
        btnRunScan.innerHTML = '<i class="fa-solid fa-bolt"></i> <span>SCAN NOW</span>';
        systemStatusText.innerText = 'SYSTEM READY';
    }
});

// Auto-Scan Toggle
btnAutoScanToggle.addEventListener('click', async () => {
    isAutoScanRunning = !isAutoScanRunning;
    autoScanText.innerText = `AUTO-SCAN: ${isAutoScanRunning ? 'ON (60s)' : 'OFF'}`;
    btnAutoScanToggle.className = `btn ${isAutoScanRunning ? 'btn-primary' : 'btn-secondary'}`;

    await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ auto_scan: isAutoScanRunning, scan_interval: 60 })
    });
});

// Audio Toggle
btnAudioToggle.addEventListener('click', () => {
    isAudioEnabled = !isAudioEnabled;
    audioIcon.className = isAudioEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark text-muted';
    if (isAudioEnabled) playTradeAlertChime();
});

// Tab Navigation
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const targetId = btn.getAttribute('data-tab');
        document.getElementById(targetId)?.classList.add('active');
    });
});

// Filter Chips
document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        currentFilter = chip.getAttribute('data-filter');
        renderSetups();
    });
});

let currentTimeframe = '5m';

window.switchTimeframe = async function(tf) {
    currentTimeframe = tf;
    document.getElementById('tf5mBtn')?.classList.toggle('active', tf === '5m');
    document.getElementById('tf15mBtn')?.classList.toggle('active', tf === '15m');
    systemStatusText.innerText = `SCANNING ON ${tf.toUpperCase()}...`;
    try {
        await fetch('/api/timeframe', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({timeframe: tf})
        });
        await fetchSMCStrategies();
        await fetchBacktest();
        await fetchSetups();
        systemStatusText.innerText = 'SYSTEM READY';
        playTradeAlertChime();
    } catch (e) {
        console.error('Error switching timeframe:', e);
        systemStatusText.innerText = 'SYSTEM READY';
    }
};

window.switchWatchlistPool = async function(poolName) {
    const sel = document.getElementById('selectWatchlistPool');
    if (sel) sel.value = poolName;

    document.getElementById('pillAllNse')?.classList.toggle('active', poolName === 'ALL_NSE_2600');
    document.getElementById('pillNifty500')?.classList.toggle('active', poolName === 'NIFTY_500');
    document.getElementById('pillFno80')?.classList.toggle('active', poolName === 'NSE_FNO_80');
    document.getElementById('pillNifty50')?.classList.toggle('active', poolName === 'NIFTY_50');
    document.getElementById('pillTop15')?.classList.toggle('active', poolName === 'TOP_15');

    systemStatusText.innerText = `SWITCHING UNIVERSE TO ${poolName}...`;
    try {
        const res = await fetch('/api/watchlist/pool', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({pool: poolName})
        });
        const data = await res.json();
        const poolCount = document.getElementById('scannerPoolCount');
        if (poolCount) poolCount.innerText = `${data.symbols_count} Symbols`;

        systemStatusText.innerText = `SCANNING ${data.symbols_count} STOCKS...`;
        await fetchSMCStrategies();
        await fetchSetups();
        await fetchLogs();
        systemStatusText.innerText = 'SYSTEM READY';
        playTradeAlertChime();
    } catch (e) {
        console.error('Error switching watchlist pool:', e);
        systemStatusText.innerText = 'SYSTEM READY';
    }
};

// Stock Search Autocomplete & Deep Analysis (Across all 2,605 NSE stocks)
const globalStockSearch = document.getElementById('globalStockSearch');
const searchDropdown = document.getElementById('searchDropdown');
let searchDebounceTimer = null;

if (globalStockSearch && searchDropdown) {
    globalStockSearch.addEventListener('input', (e) => {
        clearTimeout(searchDebounceTimer);
        const query = e.target.value.trim();
        if (query.length < 2) {
            searchDropdown.classList.remove('open');
            searchDropdown.innerHTML = '';
            return;
        }

        searchDebounceTimer = setTimeout(async () => {
            try {
                const res = await fetch(`/api/stocks/search?q=${encodeURIComponent(query)}`);
                const data = await res.json();
                const results = data.results || [];
                if (results.length === 0) {
                    searchDropdown.innerHTML = '<div style="padding: 10px; font-size: 11px; color: var(--text-muted); text-align: center;">No matching NSE stocks found.</div>';
                    searchDropdown.classList.add('open');
                    return;
                }

                searchDropdown.innerHTML = results.map(r => `
                    <div class="search-item" onclick="analyzeAndInspectStock('${r.code}', '${r.symbol}')">
                        <div>
                            <span class="search-item-sym">${r.code}</span>
                            <div class="search-item-name">${r.name}</div>
                        </div>
                        <span class="badge badge-purple" style="font-size: 9px;">ANALYZE</span>
                    </div>
                `).join('');
                searchDropdown.classList.add('open');
            } catch (err) {
                console.error('Search error:', err);
            }
        }, 200);
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.search-input-wrapper')) {
            searchDropdown.classList.remove('open');
        }
    });
}

window.analyzeAndInspectStock = async function(code, symbol) {
    searchDropdown?.classList.remove('open');
    if (globalStockSearch) globalStockSearch.value = code;
    systemStatusText.innerText = `ANALYZING ${code} (15 AGENTS)...`;

    try {
        const res = await fetch('/api/stocks/analyze', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({symbol: symbol})
        });
        const data = await res.json();
        const ticket = data.ticket;

        // Auto add to watchlist so it's tracked
        await fetch('/api/watchlist/add', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({symbol: symbol})
        });

        // Insert at beginning of setups
        allSetups.unshift(ticket);
        renderSetups();

        // Inspect ticket in modal
        window.openSetupInspector(0);
        systemStatusText.innerText = 'SYSTEM READY';
        playTradeAlertChime();
    } catch (err) {
        alert(`Error analyzing ${code}: ${err.message || 'Data fetch failed'}`);
        systemStatusText.innerText = 'SYSTEM READY';
    }
};

// 6. Fetch 8 Institutional Strategies
async function fetchSMCStrategies() {
    try {
        const res = await fetch('/api/smc-strategies');
        const data = await res.json();
        const strats = data.strategies || {};

        let totalCount = 0;

        // FVG Strategy
        const sFvg = strats.strategy_fvg || {};
        renderSMCSection('cards-smc-fvg', 'count-smc-fvg', sFvg.setups || [], 'Fair Value Gap (FVG)');
        totalCount += (sFvg.setups || []).length;

        // CPR Trend Blast Strategy
        const sCpr = strats.strategy_cpr_blast || {};
        renderSMCSection('cards-smc-cpr', 'count-smc-cpr', sCpr.setups || [], 'Narrow CPR Trend Blast');
        totalCount += (sCpr.setups || []).length;

        // Gamma Blast Strategy
        const sGamma = strats.strategy_gamma_blast || {};
        renderSMCSection('cards-smc-gamma', 'count-smc-gamma', sGamma.setups || [], 'Option Seller Trap');
        totalCount += (sGamma.setups || []).length;

        // 1. Strategy 1: SMC
        const s1 = strats.strategy_1_smc || {};
        renderSMCSection('cards-smc-1', 'count-smc-1', s1.setups || [], 'SMC BOS / CHoCH');
        totalCount += (s1.setups || []).length;

        // 2. Strategy 2: Order Block
        const s2 = strats.strategy_2_order_block || {};
        renderSMCSection('cards-smc-2', 'count-smc-2', s2.setups || [], 'Order Block Retest');
        totalCount += (s2.setups || []).length;

        // 3. Strategy 3: Sweep Entry
        const s3 = strats.strategy_3_sweep_entry || {};
        renderSMCSection('cards-smc-3', 'count-smc-3', s3.setups || [], 'Liquidity Sweep');
        totalCount += (s3.setups || []).length;

        // 4. Strategy 4: Power of 3 (AMD)
        const s4 = strats.strategy_4_power_of_3 || {};
        renderSMCSection('cards-smc-4', 'count-smc-4', s4.setups || [], 'AMD Phase 3 Distribution');
        totalCount += (s4.setups || []).length;

        // 5. Strategy 5: Liquidity Hunt
        const s5 = strats.strategy_5_liquidity_hunt || {};
        renderSMCSection('cards-smc-5', 'count-smc-5', s5.setups || [], 'BSL / SSL Target');
        totalCount += (s5.setups || []).length;

        const totalBadge = document.getElementById('smcTotalBadge');
        if (totalBadge) totalBadge.innerText = `${totalCount} ACTIVE SETUPS (${currentTimeframe.toUpperCase()})`;
    } catch (e) {
        console.error('Error fetching SMC strategies:', e);
    }
}

function renderSMCSection(containerId, countBadgeId, setups, strategyName) {
    const container = document.getElementById(containerId);
    const badge = document.getElementById(countBadgeId);
    if (badge) badge.innerText = `${setups.length} Setups`;
    if (!container) return;

    if (setups.length === 0) {
        container.innerHTML = `
            <div class="smc-empty-state">
                <i class="fa-solid fa-radar fa-2x" style="opacity: 0.3; margin-bottom: 8px;"></i>
                <p>No active setups currently meeting ${strategyName} criteria on ${currentTimeframe.toUpperCase()}.</p>
                <small class="text-muted">Scanner tracking real-time candles for fresh institutional displacement.</small>
            </div>
        `;
        return;
    }

    container.innerHTML = setups.map(s => {
        const isBull = s.direction === 'BULLISH';
        const isBear = s.direction === 'BEARISH';
        const pillClass = isBull ? 'bullish' : (isBear ? 'bearish' : 'neutral');
        const dirIcon = isBull ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down';

        return `
            <div class="smc-setup-card">
                <div class="smc-card-top">
                    <div>
                        <div class="smc-symbol text-cyan">${s.symbol}</div>
                        <span class="smc-stage-badge">${s.pattern_stage} (${s.timeframe || currentTimeframe.toUpperCase()})</span>
                    </div>
                    <span class="action-pill ${pillClass}">
                        <i class="fa-solid ${dirIcon}"></i> ${s.action}
                    </span>
                </div>

                <div class="levels-grid">
                    <div class="level-box">
                        <span class="level-title">ENTRY</span>
                        <span class="level-num text-cyan">₹${s.entry}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">STOP LOSS</span>
                        <span class="level-num text-red">₹${s.stop_loss}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">TARGET</span>
                        <span class="level-num text-green">₹${s.target}</span>
                    </div>
                </div>

                <div class="smc-rationale">
                    <i class="fa-solid fa-crosshairs text-purple"></i> ${s.rationale}
                </div>

                <div class="card-footer">
                    <span><i class="fa-solid fa-scale-balanced"></i> R:R ${s.risk_reward}</span>
                    <span><i class="fa-solid fa-users"></i> ${s.consensus_pct ? s.consensus_pct + '% Consensus' : 'SMC Confirmed'}</span>
                    <span><i class="fa-regular fa-clock"></i> ${s.timestamp || ''}</span>
                </div>
            </div>
        `;
    }).join('');
}

window.filterSMCSection = function(targetSec) {
    const sections = ['smc-sec-fvg', 'smc-sec-cpr', 'smc-sec-gamma', 'smc-sec-1', 'smc-sec-2', 'smc-sec-3', 'smc-sec-4', 'smc-sec-5'];
    document.querySelectorAll('.smc-nav-pill').forEach(p => p.classList.remove('active'));
    event?.target?.classList.add('active');

    if (targetSec === 'ALL') {
        sections.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'block';
        });
    } else {
        sections.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = (id === targetSec) ? 'block' : 'none';
        });
        const targetEl = document.getElementById(targetSec);
        if (targetEl) targetEl.scrollIntoView({ behavior: 'smooth' });
    }
};

// 7. Fetch 100-Trade Backtest & Institutional Ratings
async function fetchBacktest() {
    try {
        const res = await fetch(`/api/backtest?timeframe=${currentTimeframe}`);
        const report = await res.json();

        const grid = document.getElementById('backtestCardsGrid');
        const tableBody = document.getElementById('backtestTableBody');
        if (!grid) return;

        const stratKeys = Object.keys(report);
        grid.innerHTML = stratKeys.map(k => {
            const item = report[k];
            return `
                <div class="backtest-card">
                    <div class="backtest-card-top">
                        <div>
                            <div class="backtest-strat-name">${item.strategy_name}</div>
                            <span class="badge badge-purple" style="font-size: 10px; margin-top: 4px;">${item.institutional_tier}</span>
                        </div>
                        <span class="backtest-stars">${item.star_rating}</span>
                    </div>

                    <div class="backtest-score-banner">
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); font-family: var(--font-mono);">100 TRADES ACCURACY</span>
                            <div class="backtest-wr-val">${item.win_rate_pct}%</div>
                        </div>
                        <div style="text-align: right;">
                            <span style="font-size: 11px; color: var(--text-muted); font-family: var(--font-mono);">RATING SCORE</span>
                            <div style="font-size: 18px; font-weight: 700; color: #fbbf24; font-family: var(--font-mono);">${item.rating_score}</div>
                        </div>
                    </div>

                    <div class="backtest-stats-grid">
                        <div class="backtest-stat-box">
                            <span class="backtest-stat-label">WINS / LOSS</span>
                            <span class="backtest-stat-num text-green">${item.wins}W <span class="text-red">/ ${item.losses}L</span></span>
                        </div>
                        <div class="backtest-stat-box">
                            <span class="backtest-stat-label">AVG R:R</span>
                            <span class="backtest-stat-num text-cyan">${item.risk_reward}</span>
                        </div>
                        <div class="backtest-stat-box">
                            <span class="backtest-stat-label">PROFIT FACTOR</span>
                            <span class="backtest-stat-num text-neon">${item.profit_factor}x</span>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // Aggregate recent trades for table
        if (tableBody) {
            let allRecent = [];
            stratKeys.forEach(k => {
                const logs = report[k].recent_trades_log || [];
                logs.forEach(l => {
                    allRecent.push({...l, stratName: report[k].strategy_name});
                });
            });

            tableBody.innerHTML = allRecent.slice(0, 15).map(t => {
                const isWin = t.outcome === 'WIN';
                return `
                    <tr>
                        <td><strong>${t.trade_no}</strong></td>
                        <td>${t.stratName}</td>
                        <td><strong class="text-cyan">${t.symbol}</strong></td>
                        <td><span class="badge">${t.timeframe}</span></td>
                        <td>₹${t.entry}</td>
                        <td class="text-red">₹${t.stop_loss}</td>
                        <td class="text-green">₹${t.target}</td>
                        <td>${t.risk_reward}</td>
                        <td>
                            <span class="badge ${isWin ? 'badge-green' : 'badge-outline text-red'}">
                                ${isWin ? '<i class="fa-solid fa-check"></i> TARGET HIT' : '<i class="fa-solid fa-xmark"></i> SL HIT'}
                            </span>
                        </td>
                        <td class="${isWin ? 'text-green' : 'text-red'}"><strong>${t.pnl}</strong></td>
                    </tr>
                `;
            }).join('');
        }
    } catch (e) {
        console.error('Error fetching backtest report:', e);
    }
}

// ==================== AUTO-TRADER (UPSTOX & ₹20k CAPITAL) CLIENT ====================
let isAutoTradeEnabled = false;
let currentTradeMode = 'PAPER';

async function fetchAutoTradeState() {
    try {
        const res = await fetch('/api/autotrade');
        const data = await res.json();
        const status = data.status || {};
        const openTrades = data.open_trades || [];
        const closedTrades = data.closed_trades || [];

        isAutoTradeEnabled = status.is_auto_trade_enabled;
        currentTradeMode = status.mode || 'PAPER';

        // Update Header Button
        const headerBtn = document.getElementById('btnAutoTradeHeader');
        const headerText = document.getElementById('autoTradeHeaderText');
        if (headerText) {
            headerText.innerText = `AUTO-TRADER: ${isAutoTradeEnabled ? 'ON (' + currentTradeMode + ')' : 'OFF'}`;
        }
        if (headerBtn) {
            headerBtn.className = `btn ${isAutoTradeEnabled ? 'btn-primary' : 'btn-secondary'}`;
        }

        // Update Tab Button Labels
        const tabBadge = document.getElementById('autoTradeTabBadge');
        if (tabBadge) {
            tabBadge.innerText = `₹${(status.total_capital || 20000).toLocaleString('en-IN')}`;
        }

        const autoTradeBtnLabel = document.getElementById('autoTradeBtnLabel');
        const btnToggleAutoTrade = document.getElementById('btnToggleAutoTrade');
        if (autoTradeBtnLabel && btnToggleAutoTrade) {
            autoTradeBtnLabel.innerText = isAutoTradeEnabled ? 'STOP AUTO-TRADING' : 'ENABLE AUTO-TRADING';
            btnToggleAutoTrade.className = `btn ${isAutoTradeEnabled ? 'btn-danger' : 'btn-primary'}`;
        }

        const tradeModeBtnLabel = document.getElementById('tradeModeBtnLabel');
        if (tradeModeBtnLabel) {
            tradeModeBtnLabel.innerText = `MODE: ${currentTradeMode === 'LIVE' ? 'LIVE UPSTOX' : 'PAPER TRADING'}`;
        }

        // Metrics
        const elCap = document.getElementById('metricTotalCapital');
        if (elCap) elCap.innerText = `₹${(status.total_capital || 20000).toLocaleString('en-IN', {minimumFractionDigits: 2})}`;

        const elMargin = document.getElementById('metricAvailMargin');
        if (elMargin) elMargin.innerText = `₹${(status.available_capital || 20000).toLocaleString('en-IN', {minimumFractionDigits: 2})}`;

        const elPnl = document.getElementById('metricDailyPnl');
        if (elPnl) {
            const pnl = status.daily_pnl || 0.0;
            elPnl.innerText = `${pnl >= 0 ? '+' : ''}₹${pnl.toFixed(2)}`;
            elPnl.className = `metric-val ${pnl > 0 ? 'text-green' : (pnl < 0 ? 'text-red' : '')}`;
        }

        const elRisk = document.getElementById('metricRiskAmount');
        if (elRisk) elRisk.innerText = `₹${(status.max_risk_amount || 300).toFixed(2)} (${status.risk_per_trade_pct || 1.5}%)`;

        const elMaxLoss = document.getElementById('metricMaxDailyLoss');
        if (elMaxLoss) elMaxLoss.innerText = `-₹${(status.max_daily_loss || 1000).toFixed(2)}`;

        const elUpstox = document.getElementById('metricUpstoxStatus');
        if (elUpstox) {
            // Check Upstox connection from upstox config endpoint
            const upstoxRes = await fetch('/api/upstox/config');
            const upstoxData = await upstoxRes.json();
            if (upstoxData.is_connected) {
                elUpstox.innerText = 'Connected (Live API Ready)';
                elUpstox.className = 'metric-val text-green';
            } else {
                elUpstox.innerText = 'Not Connected (Paper Only)';
                elUpstox.className = 'metric-val text-yellow';
            }
        }

        // Open Trades Table
        const openBody = document.getElementById('openTradesTableBody');
        const openCount = document.getElementById('openTradesCount');
        if (openCount) openCount.innerText = openTrades.length;

        if (openBody) {
            if (openTrades.length === 0) {
                openBody.innerHTML = `<tr><td colspan="12" class="text-center text-muted" style="padding: 24px;">No active open trades. System waiting for institutional consensus triggers on ${currentTimeframe.toUpperCase()}...</td></tr>`;
            } else {
                openBody.innerHTML = openTrades.map(t => {
                    const isBuy = t.direction === 'BUY';
                    const pnl = t.unrealized_pnl || 0.0;
                    return `
                        <tr>
                            <td><strong>${t.trade_id}</strong></td>
                            <td>${t.timestamp}</td>
                            <td><strong class="text-cyan">${t.symbol}</strong></td>
                            <td><span style="font-size: 11px;">${t.strategy}</span></td>
                            <td><span class="badge ${isBuy ? 'badge-green' : 'badge-outline text-red'}">${t.direction}</span></td>
                            <td><strong>${t.quantity}</strong></td>
                            <td>₹${t.entry_price}</td>
                            <td class="text-cyan">₹${t.current_ltp}</td>
                            <td class="text-red">₹${t.stop_loss}</td>
                            <td class="text-green">₹${t.target}</td>
                            <td class="${pnl >= 0 ? 'text-green' : 'text-red'}"><strong>${pnl >= 0 ? '+' : ''}₹${pnl.toFixed(2)} (${t.pnl_pct}%)</strong></td>
                            <td><span class="badge badge-purple">${t.status}</span></td>
                        </tr>
                    `;
                }).join('');
            }
        }

        // Closed Trades Table
        const closedBody = document.getElementById('closedTradesTableBody');
        if (closedBody) {
            if (closedTrades.length === 0) {
                closedBody.innerHTML = `<tr><td colspan="11" class="text-center text-muted" style="padding: 24px;">No closed trades recorded yet today.</td></tr>`;
            } else {
                closedBody.innerHTML = closedTrades.map(t => {
                    const isTarget = t.status === 'TARGET HIT';
                    const pnl = t.realized_pnl || 0.0;
                    return `
                        <tr>
                            <td><strong>${t.trade_id}</strong></td>
                            <td>${t.exit_time || t.timestamp}</td>
                            <td><strong class="text-cyan">${t.symbol}</strong></td>
                            <td>${t.strategy}</td>
                            <td><span class="badge">${t.direction}</span></td>
                            <td>${t.quantity}</td>
                            <td>₹${t.entry_price}</td>
                            <td>₹${t.exit_price || t.current_ltp}</td>
                            <td>
                                <span class="badge ${isTarget ? 'badge-green' : 'badge-outline text-red'}">
                                    ${isTarget ? '🎯 TARGET HIT' : '🛑 SL HIT'}
                                </span>
                            </td>
                            <td class="${pnl >= 0 ? 'text-green' : 'text-red'}"><strong>${pnl >= 0 ? '+' : ''}₹${pnl.toFixed(2)}</strong></td>
                            <td><span class="badge badge-outline">${t.mode}</span></td>
                        </tr>
                    `;
                }).join('');
            }
        }

    } catch (e) {
        console.error('Error fetching auto-trade state:', e);
    }
}

// Toggle Auto-Trading Button Handlers
async function toggleAutoTrade() {
    try {
        const res = await fetch('/api/autotrade/toggle', { method: 'POST' });
        const data = await res.json();
        playTradeAlertChime();
        await fetchAutoTradeState();
    } catch (e) {
        console.error('Error toggling auto-trade:', e);
    }
}

document.getElementById('btnAutoTradeHeader')?.addEventListener('click', toggleAutoTrade);
document.getElementById('btnToggleAutoTrade')?.addEventListener('click', toggleAutoTrade);

// Toggle Mode (PAPER / LIVE)
document.getElementById('btnToggleTradeMode')?.addEventListener('click', async () => {
    const newMode = currentTradeMode === 'PAPER' ? 'LIVE' : 'PAPER';
    if (newMode === 'LIVE') {
        const confirmLive = confirm('WARNING: You are switching to LIVE UPSTOX BROKER TRADING. Real orders will be placed on your Upstox account. Are you sure you have verified your API Token?');
        if (!confirmLive) return;
    }
    try {
        await fetch('/api/autotrade/config', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ mode: newMode })
        });
        await fetchAutoTradeState();
    } catch (e) {
        console.error('Error switching trade mode:', e);
    }
});

// Save Auto-Trader Settings (Capital, Risk, etc.)
document.getElementById('btnSaveAutoSettings')?.addEventListener('click', async () => {
    const cap = parseFloat(document.getElementById('inputAutoCapital')?.value || '20000');
    const risk = parseFloat(document.getElementById('selectAutoRisk')?.value || '1.5');
    const mode = document.getElementById('selectAutoMode')?.value || 'PAPER';
    const cons = parseFloat(document.getElementById('selectAutoConsensus')?.value || '70');

    try {
        await fetch('/api/autotrade/config', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                total_capital: cap,
                risk_per_trade_pct: risk,
                mode: mode,
                min_consensus_required: cons
            })
        });
        alert(`Auto-Trader settings updated! Capital: ₹${cap.toLocaleString('en-IN')}, Risk: ${risk}%, Mode: ${mode}`);
        await fetchAutoTradeState();
    } catch (e) {
        alert('Failed to save settings.');
    }
});

// Clear Logs
document.getElementById('btnClearLogs')?.addEventListener('click', () => {
    terminalLogs.innerHTML = '<div class="log-line text-muted">[SYSTEM] Screen cleared.</div>';
});

// Initial Load & Heartbeat Loop
async function init() {
    await fetchMarketPulse();
    await fetchAutoTradeState();
    await fetchSMCStrategies();
    await fetchBacktest();
    await fetchSetups();
    await fetchAgents();
    await fetchLogs();

    // Periodic UI refresh
    setInterval(fetchMarketPulse, 10000);   // 10s market pulse
    setInterval(fetchAutoTradeState, 8000); // 8s auto-trade state refresh
    setInterval(fetchSMCStrategies, 12000); // 12s SMC strategies refresh
    setInterval(fetchBacktest, 25000);      // 25s backtest refresh
    setInterval(fetchSetups, 15000);        // 15s setups refresh
    setInterval(fetchAgents, 20000);        // 20s agent states
    setInterval(fetchLogs, 15000);          // 15s logs
}

init();


