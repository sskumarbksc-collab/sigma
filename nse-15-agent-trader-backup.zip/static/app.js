// NSE 15-AI-Agent Trading Terminal Frontend Engine
let allSetups = [];
let currentFilter = 'ALL';
let isAudioEnabled = true;
let isAutoScanRunning = false;
let audioCtx = null;

// Initialize Web Audio Context on user interaction
function getAudioContext() {
    if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
        audioCtx.resume();
    }
    return audioCtx;
}

// Play modern futuristic chime for approved high-conviction setup
function playTradeAlertChime() {
    if (!isAudioEnabled) return;
    try {
        const ctx = getAudioContext();
        const now = ctx.currentTime;
        
        // Two-tone pleasant institutional notification chime (E5 -> B5)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(659.25, now); // E5
        osc1.frequency.setValueAtTime(987.77, now + 0.12); // B5
        
        gain1.gain.setValueAtTime(0.01, now);
        gain1.gain.linearRampToValueAtTime(0.2, now + 0.05);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        
        osc1.start(now);
        osc1.stop(now + 0.5);
    } catch (e) {
        console.warn('Audio chime notice:', e);
    }
}

// DOM Elements
const niftyLtp = document.getElementById('niftyLtp');
const niftyChange = document.getElementById('niftyChange');
const bnLtp = document.getElementById('bnLtp');
const bnChange = document.getElementById('bnChange');
const vixVal = document.getElementById('vixVal');
const vixRegime = document.getElementById('vixRegime');
const breadthRatio = document.getElementById('breadthRatio');
const breadthSentiment = document.getElementById('breadthSentiment');
const lastScanTime = document.getElementById('lastScanTime');
const setupsGrid = document.getElementById('setupsGrid');
const setupCountBadge = document.getElementById('setupCountBadge');
const agentsMatrixGrid = document.getElementById('agentsMatrixGrid');
const scannerTableBody = document.getElementById('scannerTableBody');
const terminalLogs = document.getElementById('terminalLogs');

const btnRunScan = document.getElementById('btnRunScan');
const btnAutoScanToggle = document.getElementById('btnAutoScanToggle');
const autoScanText = document.getElementById('autoScanText');
const btnAudioToggle = document.getElementById('btnAudioToggle');
const audioIcon = document.getElementById('audioIcon');
const systemStatusText = document.getElementById('systemStatusText');

// Setup Inspector Modal
const setupInspectorModal = document.getElementById('setupInspectorModal');
const closeInspectorBtn = document.getElementById('closeInspectorBtn');
const modalSymbolTitle = document.getElementById('modalSymbolTitle');
const modalActionBadge = document.getElementById('modalActionBadge');
const modalInstrument = document.getElementById('modalInstrument');
const modalEntry = document.getElementById('modalEntry');
const modalStopLoss = document.getElementById('modalStopLoss');
const modalTarget1 = document.getElementById('modalTarget1');
const modalTarget2 = document.getElementById('modalTarget2');
const modalRiskReward = document.getElementById('modalRiskReward');
const modalConsensus = document.getElementById('modalConsensus');
const modalMasterThesis = document.getElementById('modalMasterThesis');
const modalAgentVotesList = document.getElementById('modalAgentVotesList');

// Upstox Modal
const upstoxModal = document.getElementById('upstoxModal');
const btnUpstoxModal = document.getElementById('btnUpstoxModal');
const closeUpstoxBtn = document.getElementById('closeUpstoxBtn');
const btnCancelUpstox = document.getElementById('btnCancelUpstox');
const btnSaveUpstox = document.getElementById('btnSaveUpstox');
const upstoxApiKey = document.getElementById('upstoxApiKey');
const upstoxApiSecret = document.getElementById('upstoxApiSecret');
const upstoxAccessToken = document.getElementById('upstoxAccessToken');
const upstoxConnStatus = document.getElementById('upstoxConnStatus');

// 1. Fetch Market Pulse
async function fetchMarketPulse() {
    try {
        const res = await fetch('/api/pulse');
        const data = await res.json();
        
        // Nifty 50
        const n = data.nifty50 || {};
        niftyLtp.innerText = `₹${n.ltp?.toLocaleString('en-IN') || '--'}`;
        const nSign = n.change_pct >= 0 ? '+' : '';
        niftyChange.innerText = `${nSign}${n.change_pct || 0}%`;
        niftyChange.className = `pulse-change ${n.change_pct >= 0 ? 'bullish' : 'bearish'}`;

        // Bank Nifty
        const bn = data.banknifty || {};
        bnLtp.innerText = `₹${bn.ltp?.toLocaleString('en-IN') || '--'}`;
        const bnSign = bn.change_pct >= 0 ? '+' : '';
        bnChange.innerText = `${bnSign}${bn.change_pct || 0}%`;
        bnChange.className = `pulse-change ${bn.change_pct >= 0 ? 'bullish' : 'bearish'}`;

        // India VIX
        const v = data.india_vix || {};
        vixVal.innerText = v.value || '--';
        vixRegime.innerText = v.regime || 'NORMAL';

        // Breadth
        const b = data.market_breadth || {};
        breadthRatio.innerText = `${b.advances || 0}A / ${b.declines || 0}D (${b.ratio || 1.0}x)`;
        breadthSentiment.innerText = b.sentiment || 'BALANCED';
        breadthSentiment.className = `pulse-tag ${(b.sentiment || '').includes('BULL') ? 'text-green' : 'text-red'}`;

    } catch (e) {
        console.error('Error fetching market pulse:', e);
    }
}

// 2. Fetch Setups
async function fetchSetups() {
    try {
        const res = await fetch('/api/setups');
        const data = await res.json();
        allSetups = data.setups || [];
        lastScanTime.innerText = data.last_scan || '--:--:--';
        
        renderSetups();
        renderScannerTable();
    } catch (e) {
        console.error('Error fetching setups:', e);
    }
}

// Render Setup Cards
function renderSetups() {
    let filtered = allSetups;
    if (currentFilter === 'APPROVED') {
        filtered = allSetups.filter(s => s.status === 'APPROVED');
    } else if (currentFilter === 'BULLISH') {
        filtered = allSetups.filter(s => s.direction === 'BULLISH');
    } else if (currentFilter === 'BEARISH') {
        filtered = allSetups.filter(s => s.direction === 'BEARISH');
    }

    const approvedCount = allSetups.filter(s => s.status === 'APPROVED').length;
    setupCountBadge.innerText = `${approvedCount} APPROVED`;

    if (filtered.length === 0) {
        setupsGrid.innerHTML = `
            <div class="loading-state">
                <i class="fa-solid fa-filter fa-2x text-muted" style="margin-bottom: 12px;"></i>
                <p>No setups matching filter "${currentFilter}".</p>
                <small class="text-muted">Click "SCAN NOW" or wait for next automatic sweep cycle.</small>
            </div>
        `;
        return;
    }

    setupsGrid.innerHTML = filtered.map((s, idx) => {
        const isApproved = s.status === 'APPROVED';
        const isBullish = s.direction === 'BULLISH';
        const isBearish = s.direction === 'BEARISH';
        const cardClass = isApproved ? (isBearish ? 'card-approved bearish' : 'card-approved') : '';
        const pillClass = isBullish ? 'bullish' : (isBearish ? 'bearish' : 'neutral');
        const fillClass = isBullish ? 'fill-green' : (isBearish ? 'fill-red' : 'fill-yellow');

        return `
            <div class="setup-card ${cardClass}" onclick="openSetupInspector(${idx})">
                <div class="card-top">
                    <div class="symbol-group">
                        <span class="symbol-name">${s.symbol}</span>
                        <span class="instrument-name">${s.instrument}</span>
                    </div>
                    <span class="action-pill ${pillClass}">
                        ${isBullish ? '<i class="fa-solid fa-arrow-trend-up"></i>' : (isBearish ? '<i class="fa-solid fa-arrow-trend-down"></i>' : '<i class="fa-solid fa-minus"></i>')}
                        ${s.action}
                    </span>
                </div>

                <div class="levels-grid">
                    <div class="level-box">
                        <span class="level-title">ENTRY ZONE</span>
                        <span class="level-num text-cyan">₹${s.entry}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">STOP LOSS</span>
                        <span class="level-num text-red">₹${s.stop_loss}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">TARGET 1</span>
                        <span class="level-num text-green">₹${s.target1}</span>
                    </div>
                </div>

                <div class="consensus-wrapper">
                    <div class="consensus-header">
                        <span>15-AGENT CONSENSUS</span>
                        <strong class="${isBullish ? 'text-green' : (isBearish ? 'text-red' : 'text-yellow')}">
                            ${s.consensus_pct}% (${s.bullish_votes}B / ${s.bearish_votes}S)
                        </strong>
                    </div>
                    <div class="consensus-progress-track">
                        <div class="consensus-progress-fill ${fillClass}" style="width: ${s.consensus_pct}%;"></div>
                    </div>
                </div>

                <div class="card-footer">
                    <span><i class="fa-solid fa-scale-balanced"></i> R:R ${s.risk_reward}</span>
                    <span class="${isApproved ? 'text-green' : 'text-muted'}">
                        ${isApproved ? '<i class="fa-solid fa-circle-check"></i> INSTITUTIONAL PASS' : '<i class="fa-solid fa-eye"></i> WATCHLIST'}
                    </span>
                    <span><i class="fa-regular fa-clock"></i> ${s.timestamp}</span>
                </div>
            </div>
        `;
    }).join('');
}

// 3. Render Watchlist Scanner Table
function renderScannerTable() {
    if (allSetups.length === 0) {
        scannerTableBody.innerHTML = `<tr><td colspan="9" class="text-center text-muted">No data scanned yet.</td></tr>`;
        return;
    }

    scannerTableBody.innerHTML = allSetups.map((s, idx) => {
        const isBull = s.direction === 'BULLISH';
        const isBear = s.direction === 'BEARISH';
        const pillClass = isBull ? 'bullish' : (isBear ? 'bearish' : 'neutral');

        return `
            <tr>
                <td><strong>${s.symbol}</strong></td>
                <td>₹${s.ltp}</td>
                <td class="${isBull ? 'text-green' : (isBear ? 'text-red' : 'text-muted')}">
                    ${isBull ? '+' : ''}${((s.entry - s.stop_loss) / s.entry * 100).toFixed(2)}%
                </td>
                <td><span class="action-pill ${pillClass}">${s.action}</span></td>
                <td>${s.instrument}</td>
                <td><strong class="${isBull ? 'text-green' : (isBear ? 'text-red' : 'text-yellow')}">${s.consensus_pct}%</strong></td>
                <td><small>${s.bullish_votes} Bull / ${s.bearish_votes} Bear / ${s.neutral_votes} Neu</small></td>
                <td>
                    <span class="badge ${s.status === 'APPROVED' ? 'badge-cyan' : ''}">
                        ${s.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-secondary btn-sm" onclick="openSetupInspector(${idx})">
                        <i class="fa-solid fa-magnifying-glass-chart"></i> Inspect
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// 4. Fetch 15 AI Agents Live Matrix
async function fetchAgents() {
    try {
        const res = await fetch('/api/agents');
        const data = await res.json();
        const agents = data.agents || [];

        agentsMatrixGrid.innerHTML = agents.map(a => {
            const verdict = a.last_verdict;
            const vote = verdict ? verdict.vote : 'IDLE';
            const voteClass = vote === 'BULLISH' ? 'text-green' : (vote === 'BEARISH' ? 'text-red' : 'text-yellow');
            const score = verdict ? verdict.score : 0.0;
            const rationale = verdict ? verdict.rationale : 'Awaiting next market candle evaluation cycle.';

            return `
                <div class="agent-matrix-card">
                    <div class="agent-card-header">
                        <div class="agent-title-row">
                            <span class="agent-badge-id">${a.agent_id}</span>
                            <div>
                                <div class="agent-name-text">${a.name}</div>
                                <div class="agent-layer-tag">${a.layer}</div>
                            </div>
                        </div>
                    </div>

                    <div class="agent-verdict-banner">
                        <span>VERDICT: <strong class="${voteClass}">${vote}</strong></span>
                        <span>CONFIDENCE: <strong>${verdict ? verdict.confidence + '%' : '--'}</strong></span>
                    </div>

                    <div class="agent-rationale-text">
                        ${rationale}
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) {
        console.error('Error fetching agents:', e);
    }
}

// 5. Fetch Logs
async function fetchLogs() {
    try {
        const res = await fetch('/api/logs');
        const data = await res.json();
        const logs = data.logs || [];
        if (logs.length > 0) {
            terminalLogs.innerHTML = logs.map(l => `<div class="log-line">${l}</div>`).join('');
            terminalLogs.scrollTop = terminalLogs.scrollHeight;
        }
    } catch (e) {
        console.error('Error fetching logs:', e);
    }
}

// Open Setup Inspector Modal (All 15 Agent Votes)
window.openSetupInspector = function(index) {
    const s = allSetups[index];
    if (!s) return;

    modalSymbolTitle.innerText = s.symbol;
    modalInstrument.innerText = s.instrument;
    modalActionBadge.innerText = s.action;
    modalActionBadge.className = `badge badge-outline ${s.direction === 'BULLISH' ? 'text-green' : (s.direction === 'BEARISH' ? 'text-red' : 'text-yellow')}`;

    modalEntry.innerText = `₹${s.entry}`;
    modalStopLoss.innerText = `₹${s.stop_loss}`;
    modalTarget1.innerText = `₹${s.target1}`;
    modalTarget2.innerText = `₹${s.target2}`;
    modalRiskReward.innerText = s.risk_reward;
    modalConsensus.innerText = `${s.consensus_pct}% (${s.bullish_votes}B / ${s.bearish_votes}S)`;

    modalMasterThesis.innerText = s.master_thesis || 'No rationale available.';

    // Populate individual 15 agent breakdowns
    const breakdown = s.agent_breakdown || [];
    modalAgentVotesList.innerHTML = breakdown.map(a => {
        const vClass = a.vote === 'BULLISH' ? 'text-green' : (a.vote === 'BEARISH' ? 'text-red' : 'text-yellow');
        return `
            <div class="vote-item">
                <div class="vote-header">
                    <span><strong>Agent ${a.agent_id}: ${a.name}</strong> (${a.role})</span>
                    <span class="${vClass}">${a.vote} (${a.confidence}%)</span>
                </div>
                <div class="vote-rationale">${a.rationale}</div>
            </div>
        `;
    }).join('');

    setupInspectorModal.classList.add('open');
};

// Close modals
closeInspectorBtn.addEventListener('click', () => setupInspectorModal.classList.remove('open'));
setupInspectorModal.addEventListener('click', (e) => {
    if (e.target === setupInspectorModal) setupInspectorModal.classList.remove('open');
});

btnUpstoxModal.addEventListener('click', async () => {
    try {
        const res = await fetch('/api/upstox/config');
        const data = await res.json();
        upstoxApiKey.value = data.api_key || '';
        upstoxConnStatus.innerText = data.is_connected ? 'Connected (Live Broker Feed)' : 'Not Connected (Using Open Data)';
        upstoxConnStatus.className = data.is_connected ? 'text-green' : 'text-yellow';
    } catch (e) {}
    upstoxModal.classList.add('open');
});

closeUpstoxBtn.addEventListener('click', () => upstoxModal.classList.remove('open'));
btnCancelUpstox.addEventListener('click', () => upstoxModal.classList.remove('open'));

btnSaveUpstox.addEventListener('click', async () => {
    const payload = {
        api_key: upstoxApiKey.value.trim(),
        api_secret: upstoxApiSecret.value.trim(),
        access_token: upstoxAccessToken.value.trim()
    };
    try {
        const res = await fetch('/api/upstox/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        alert(data.message || 'Saved!');
        upstoxModal.classList.remove('open');
    } catch (e) {
        alert('Failed to save Upstox configuration.');
    }
});

// Run Scan Button
btnRunScan.addEventListener('click', async () => {
    btnRunScan.disabled = true;
    btnRunScan.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> <span>SCANNING...</span>';
    systemStatusText.innerText = '15 AGENTS SCANNING...';

    try {
        await fetch('/api/scan', { method: 'POST' });
        // Poll status until scan finishes
        const poll = setInterval(async () => {
            const statusRes = await fetch('/api/status');
            const statusData = await statusRes.json();
            if (!statusData.is_scanning) {
                clearInterval(poll);
                btnRunScan.disabled = false;
                btnRunScan.innerHTML = '<i class="fa-solid fa-bolt"></i> <span>SCAN NOW</span>';
                systemStatusText.innerText = 'SYSTEM READY';
                await fetchSetups();
                await fetchAgents();
                await fetchLogs();
                playTradeAlertChime();
            }
        }, 2000);
    } catch (e) {
        btnRunScan.disabled = false;
        btnRunScan.innerHTML = '<i class="fa-solid fa-bolt"></i> <span>SCAN NOW</span>';
        systemStatusText.innerText = 'SYSTEM READY';
    }
});

// Auto-Scan Toggle
btnAutoScanToggle.addEventListener('click', async () => {
    isAutoScanRunning = !isAutoScanRunning;
    autoScanText.innerText = `AUTO-SCAN: ${isAutoScanRunning ? 'ON (60s)' : 'OFF'}`;
    btnAutoScanToggle.className = `btn ${isAutoScanRunning ? 'btn-primary' : 'btn-secondary'}`;

    await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ auto_scan: isAutoScanRunning, scan_interval: 60 })
    });
});

// Audio Toggle
btnAudioToggle.addEventListener('click', () => {
    isAudioEnabled = !isAudioEnabled;
    audioIcon.className = isAudioEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark text-muted';
    if (isAudioEnabled) playTradeAlertChime();
});

// Tab Navigation
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const targetId = btn.getAttribute('data-tab');
        document.getElementById(targetId)?.classList.add('active');
    });
});

// Filter Chips
document.querySelectorAll('.filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        currentFilter = chip.getAttribute('data-filter');
        renderSetups();
    });
});

// 6. Fetch 5 SMC Institutional Strategies
async function fetchSMCStrategies() {
    try {
        const res = await fetch('/api/smc-strategies');
        const data = await res.json();
        const strats = data.strategies || {};

        let totalCount = 0;
        // 1. Strategy 1: SMC
        const s1 = strats.strategy_1_smc || {};
        renderSMCSection('cards-smc-1', 'count-smc-1', s1.setups || [], 'SMC BOS / CHoCH');
        totalCount += (s1.setups || []).length;

        // 2. Strategy 2: Order Block
        const s2 = strats.strategy_2_order_block || {};
        renderSMCSection('cards-smc-2', 'count-smc-2', s2.setups || [], 'Order Block Retest');
        totalCount += (s2.setups || []).length;

        // 3. Strategy 3: Sweep Entry
        const s3 = strats.strategy_3_sweep_entry || {};
        renderSMCSection('cards-smc-3', 'count-smc-3', s3.setups || [], 'Liquidity Sweep');
        totalCount += (s3.setups || []).length;

        // 4. Strategy 4: Power of 3 (AMD)
        const s4 = strats.strategy_4_power_of_3 || {};
        renderSMCSection('cards-smc-4', 'count-smc-4', s4.setups || [], 'AMD Phase 3 Distribution');
        totalCount += (s4.setups || []).length;

        // 5. Strategy 5: Liquidity Hunt
        const s5 = strats.strategy_5_liquidity_hunt || {};
        renderSMCSection('cards-smc-5', 'count-smc-5', s5.setups || [], 'BSL / SSL Target');
        totalCount += (s5.setups || []).length;

        const totalBadge = document.getElementById('smcTotalBadge');
        if (totalBadge) totalBadge.innerText = `${totalCount} ACTIVE SETUPS`;
    } catch (e) {
        console.error('Error fetching SMC strategies:', e);
    }
}

function renderSMCSection(containerId, countBadgeId, setups, strategyName) {
    const container = document.getElementById(containerId);
    const badge = document.getElementById(countBadgeId);
    if (badge) badge.innerText = `${setups.length} Setups`;
    if (!container) return;

    if (setups.length === 0) {
        container.innerHTML = `
            <div class="smc-empty-state">
                <i class="fa-solid fa-radar fa-2x" style="opacity: 0.3; margin-bottom: 8px;"></i>
                <p>No active setups currently meeting ${strategyName} criteria.</p>
                <small class="text-muted">Scanner is continuously tracking live candles for new triggers.</small>
            </div>
        `;
        return;
    }

    container.innerHTML = setups.map(s => {
        const isBull = s.direction === 'BULLISH';
        const isBear = s.direction === 'BEARISH';
        const pillClass = isBull ? 'bullish' : (isBear ? 'bearish' : 'neutral');
        const dirIcon = isBull ? 'fa-arrow-trend-up' : 'fa-arrow-trend-down';

        return `
            <div class="smc-setup-card">
                <div class="smc-card-top">
                    <div>
                        <div class="smc-symbol text-cyan">${s.symbol}</div>
                        <span class="smc-stage-badge">${s.pattern_stage}</span>
                    </div>
                    <span class="action-pill ${pillClass}">
                        <i class="fa-solid ${dirIcon}"></i> ${s.action}
                    </span>
                </div>

                <div class="levels-grid">
                    <div class="level-box">
                        <span class="level-title">ENTRY</span>
                        <span class="level-num text-cyan">₹${s.entry}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">STOP LOSS</span>
                        <span class="level-num text-red">₹${s.stop_loss}</span>
                    </div>
                    <div class="level-box">
                        <span class="level-title">TARGET</span>
                        <span class="level-num text-green">₹${s.target}</span>
                    </div>
                </div>

                <div class="smc-rationale">
                    <i class="fa-solid fa-crosshairs text-purple"></i> ${s.rationale}
                </div>

                <div class="card-footer">
                    <span><i class="fa-solid fa-scale-balanced"></i> R:R ${s.risk_reward}</span>
                    <span><i class="fa-solid fa-users"></i> ${s.consensus_pct ? s.consensus_pct + '% Consensus' : 'SMC Confirmed'}</span>
                    <span><i class="fa-regular fa-clock"></i> ${s.timestamp || ''}</span>
                </div>
            </div>
        `;
    }).join('');
}

window.filterSMCSection = function(targetSec) {
    const sections = ['smc-sec-1', 'smc-sec-2', 'smc-sec-3', 'smc-sec-4', 'smc-sec-5'];
    if (targetSec === 'ALL') {
        sections.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.style.display = 'block';
        });
    } else {
        const num = targetSec.replace('smc-', '');
        sections.forEach((id, idx) => {
            const el = document.getElementById(id);
            if (el) el.style.display = (idx + 1 === parseInt(num)) ? 'block' : 'none';
        });
        const targetEl = document.getElementById(`smc-sec-${num}`);
        if (targetEl) targetEl.scrollIntoView({ behavior: 'smooth' });
    }
};

// Clear Logs
document.getElementById('btnClearLogs')?.addEventListener('click', () => {
    terminalLogs.innerHTML = '<div class="log-line text-muted">[SYSTEM] Screen cleared.</div>';
});

// Initial Load & Heartbeat Loop
async function init() {
    await fetchMarketPulse();
    await fetchSMCStrategies();
    await fetchSetups();
    await fetchAgents();
    await fetchLogs();

    // Periodic UI refresh
    setInterval(fetchMarketPulse, 10000);   // 10s market pulse
    setInterval(fetchSMCStrategies, 12000); // 12s SMC strategies refresh
    setInterval(fetchSetups, 15000);        // 15s setups refresh
    setInterval(fetchAgents, 20000);        // 20s agent states
    setInterval(fetchLogs, 15000);          // 15s logs
}

init();

