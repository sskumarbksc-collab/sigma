import numpy as np
import pandas as pd
from typing import Dict, Any, List, Optional
from datetime import datetime

class SMCStrategyEngine:
    """
    Dedicated Smart Money Concept (SMC) & Institutional Strategy Engine.
    Implements the 5 precise strategies from the institutional trading infographics:
      1. SMC Market Structure (BOS & CHoCH)
      2. Order Block (OB Institutional Retest)
      3. Sweep Entry (Liquidity Grab & Reversal)
      4. Power of 3 (AMD - Accumulation, Manipulation, Distribution)
      5. Liquidity Hunt (BSL / SSL Delivery)
    """

    def __init__(self):
        pass

    def analyze_all_strategies(self, stock_data: Dict[str, Any], raw_df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """
        Evaluates a stock against all 5 SMC strategies.
        Returns categorized setups for each strategy.
        """
        symbol = stock_data.get("symbol", "")
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        atr = ind.get("atr", max(1.0, ltp * 0.01))

        # We will extract swing points, candle wicks, ranges, and zones
        setups_by_strategy = {
            "strategy_1_smc": None,
            "strategy_2_order_block": None,
            "strategy_3_sweep_entry": None,
            "strategy_4_power_of_3": None,
            "strategy_5_liquidity_hunt": None,
            "strategy_fvg": None,
            "strategy_cpr_blast": None,
            "strategy_gamma_blast": None
        }

        # If raw candle dataframe is provided, we do high-precision detection;
        # otherwise we derive from technical indicators and candle geometry.
        df = raw_df

        # Fallback or synthetic multi-candle analysis if df is provided
        if df is not None and len(df) >= 20:
            setups_by_strategy["strategy_1_smc"] = self._detect_smc_structure(symbol, ltp, df, atr)
            setups_by_strategy["strategy_2_order_block"] = self._detect_order_block(symbol, ltp, df, atr)
            setups_by_strategy["strategy_3_sweep_entry"] = self._detect_sweep_entry(symbol, ltp, df, atr)
            setups_by_strategy["strategy_4_power_of_3"] = self._detect_power_of_3(symbol, ltp, df, atr)
            setups_by_strategy["strategy_5_liquidity_hunt"] = self._detect_liquidity_hunt(symbol, ltp, df, atr)
            setups_by_strategy["strategy_fvg"] = self._detect_fvg(symbol, ltp, df, atr)
            setups_by_strategy["strategy_cpr_blast"] = self._detect_cpr_blast(symbol, ltp, df, atr)
            setups_by_strategy["strategy_gamma_blast"] = self._detect_gamma_blast(symbol, ltp, df, atr, stock_data)
        else:
            # Indicator-derived evaluation
            setups_by_strategy["strategy_1_smc"] = self._derive_smc_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_2_order_block"] = self._derive_ob_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_3_sweep_entry"] = self._derive_sweep_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_4_power_of_3"] = self._derive_amd_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_5_liquidity_hunt"] = self._derive_liquidity_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_fvg"] = self._derive_fvg_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_cpr_blast"] = self._derive_cpr_from_indicators(symbol, stock_data, atr)
            setups_by_strategy["strategy_gamma_blast"] = self._derive_gamma_from_indicators(symbol, stock_data, atr)

        return setups_by_strategy

    # =========================================================================
    # 1. SMART MONEY CONCEPT (SMC) - BOS & CHoCH
    # =========================================================================
    def _detect_smc_structure(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        highs = df['High'].tail(15).values
        lows = df['Low'].tail(15).values
        closes = df['Close'].tail(15).values

        recent_swing_high = float(np.max(highs[:-2]))
        recent_swing_low = float(np.min(lows[:-2]))
        curr_close = float(closes[-1])
        prev_close = float(closes[-2])

        # Bullish BOS / CHoCH: Price breaks above recent swing high with strong body
        if curr_close > recent_swing_high and prev_close <= recent_swing_high:
            sl = round(recent_swing_low, 2)
            tgt = round(curr_close + (curr_close - sl) * 2.0, 2)
            rr = round((tgt - curr_close) / max(0.1, curr_close - sl), 2)
            return {
                "strategy_id": 1,
                "strategy_name": "Smart Money Concept (SMC)",
                "strategy_badge": "BOS & CHoCH",
                "symbol": symbol,
                "action": "BUY CALL / LONG",
                "direction": "BULLISH",
                "entry": round(curr_close, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{rr}",
                "pattern_stage": "BOS Confirmed (Break of Structure)",
                "rationale": f"Bullish BOS confirmed! Price ({curr_close:.2f}) broke above previous swing high ({recent_swing_high:.2f}). Smart money displacement active after Inducement (IDM).",
                "key_levels": {"bos_level": recent_swing_high, "idm_zone": round((curr_close + sl)/2, 2), "invalidation": sl}
            }
        # Bearish BOS / CHoCH: Price breaks below recent swing low
        elif curr_close < recent_swing_low and prev_close >= recent_swing_low:
            sl = round(recent_swing_high, 2)
            tgt = round(curr_close - (sl - curr_close) * 2.0, 2)
            rr = round((curr_close - tgt) / max(0.1, sl - curr_close), 2)
            return {
                "strategy_id": 1,
                "strategy_name": "Smart Money Concept (SMC)",
                "strategy_badge": "BOS & CHoCH",
                "symbol": symbol,
                "action": "BUY PUT / SHORT",
                "direction": "BEARISH",
                "entry": round(curr_close, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{rr}",
                "pattern_stage": "BOS Confirmed (Bearish Structure)",
                "rationale": f"Bearish BOS confirmed! Price ({curr_close:.2f}) broke below previous swing low ({recent_swing_low:.2f}). Institutional change of character completed.",
                "key_levels": {"bos_level": recent_swing_low, "idm_zone": round((curr_close + sl)/2, 2), "invalidation": sl}
            }
        return None

    # =========================================================================
    # 2. ORDER BLOCK (OB) - INSTITUTIONAL ZONES
    # =========================================================================
    def _detect_order_block(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # Look back 5 to 12 candles to find an impulsive origin candle (Last opposite candle before strong displacement)
        opens = df['Open'].values
        closes = df['Close'].values
        highs = df['High'].values
        lows = df['Low'].values

        n = len(df)
        for i in range(n - 4, max(4, n - 12), -1):
            # Bullish OB Check: Candle i was RED (close < open), followed by 2 strong GREEN candles
            if closes[i] < opens[i] and closes[i+1] > opens[i+1] and closes[i+2] > opens[i+2]:
                displacement = closes[i+2] - opens[i+1]
                if displacement > atr * 1.2:
                    ob_high = float(highs[i])
                    ob_low = float(lows[i])
                    # Current candle is testing/retesting this OB zone
                    if ob_low * 0.998 <= ltp <= ob_high * 1.008:
                        sl = round(ob_low - (atr * 0.3), 2)
                        tgt = round(ltp + (ltp - sl) * 2.2, 2)
                        rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
                        return {
                            "strategy_id": 2,
                            "strategy_name": "Order Block (OB)",
                            "strategy_badge": "Institutional Demand Zone",
                            "symbol": symbol,
                            "action": "BUY CALL / RE-TEST ENTRY",
                            "direction": "BULLISH",
                            "entry": round(ltp, 2),
                            "stop_loss": sl,
                            "target": tgt,
                            "risk_reward": f"1:{rr}",
                            "pattern_stage": "OB Zone Retest & Reaction",
                            "rationale": f"Price returned to Bullish Order Block ({ob_low:.2f} - {ob_high:.2f}). This is the last down candle before big institutional move. High probability bounce zone.",
                            "key_levels": {"ob_top": ob_high, "ob_bottom": ob_low, "stop_loss": sl}
                        }

            # Bearish OB Check: Candle i was GREEN, followed by 2 strong RED candles
            elif closes[i] > opens[i] and closes[i+1] < opens[i+1] and closes[i+2] < opens[i+2]:
                displacement = opens[i+1] - closes[i+2]
                if displacement > atr * 1.2:
                    ob_high = float(highs[i])
                    ob_low = float(lows[i])
                    # Current candle is retesting this Bearish OB zone
                    if ob_low * 0.992 <= ltp <= ob_high * 1.002:
                        sl = round(ob_high + (atr * 0.3), 2)
                        tgt = round(ltp - (sl - ltp) * 2.2, 2)
                        rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
                        return {
                            "strategy_id": 2,
                            "strategy_name": "Order Block (OB)",
                            "strategy_badge": "Institutional Supply Zone",
                            "symbol": symbol,
                            "action": "BUY PUT / RE-TEST SHORT",
                            "direction": "BEARISH",
                            "entry": round(ltp, 2),
                            "stop_loss": sl,
                            "target": tgt,
                            "risk_reward": f"1:{rr}",
                            "pattern_stage": "Supply OB Retest",
                            "rationale": f"Price rallied into Bearish Order Block ({ob_low:.2f} - {ob_high:.2f}). Institutions defending their short positions. Rejection expected.",
                            "key_levels": {"ob_top": ob_high, "ob_bottom": ob_low, "stop_loss": sl}
                        }
        return None

    # =========================================================================
    # 3. SWEEP ENTRY - LIQUIDITY SWEEP STRATEGY
    # =========================================================================
    def _detect_sweep_entry(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # A sweep happens when a candle pokes beyond a key swing high/low, but closes back inside with a long wick
        highs = df['High'].values
        lows = df['Low'].values
        opens = df['Open'].values
        closes = df['Close'].values

        prev_swing_high = float(np.max(highs[-10:-1]))
        prev_swing_low = float(np.min(lows[-10:-1]))

        curr_high = float(highs[-1])
        curr_low = float(lows[-1])
        curr_open = float(opens[-1])
        curr_close = float(closes[-1])
        candle_range = max(0.1, curr_high - curr_low)

        # Bearish Liquidity Sweep (Swept Highs -> Dumps):
        # Spiked above prev_swing_high, but closed below it, with long upper wick
        upper_wick = curr_high - max(curr_open, curr_close)
        if curr_high > prev_swing_high and curr_close < prev_swing_high and (upper_wick / candle_range) >= 0.40:
            sl = round(curr_high + (atr * 0.1), 2)
            tgt = round(curr_close - (sl - curr_close) * 2.5, 2)
            rr = round((curr_close - tgt) / max(0.1, sl - curr_close), 2)
            return {
                "strategy_id": 3,
                "strategy_name": "Sweep Entry",
                "strategy_badge": "Liquidity Sweep & Reversal",
                "symbol": symbol,
                "action": "BUY PUT / SWEEP REVERSAL",
                "direction": "BEARISH",
                "entry": round(curr_close, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{rr}",
                "pattern_stage": "High Liquidity Swept (Judas Wick)",
                "rationale": f"Buy-side liquidity swept! Price spiked to {curr_high:.2f} taking out stop-losses above {prev_swing_high:.2f}, but rejected with {upper_wick/candle_range*100:.0f}% upper wick. CHoCH reversal in play.",
                "key_levels": {"swept_high": prev_swing_high, "sweep_extreme": curr_high, "stop_loss": sl}
            }

        # Bullish Liquidity Sweep (Swept Lows -> Pumps):
        # Spiked below prev_swing_low, but closed back above it, with long lower wick
        lower_wick = min(curr_open, curr_close) - curr_low
        if curr_low < prev_swing_low and curr_close > prev_swing_low and (lower_wick / candle_range) >= 0.40:
            sl = round(curr_low - (atr * 0.1), 2)
            tgt = round(curr_close + (curr_close - sl) * 2.5, 2)
            rr = round((tgt - curr_close) / max(0.1, curr_close - sl), 2)
            return {
                "strategy_id": 3,
                "strategy_name": "Sweep Entry",
                "strategy_badge": "Liquidity Sweep & Reversal",
                "symbol": symbol,
                "action": "BUY CALL / SWEEP BOUNCE",
                "direction": "BULLISH",
                "entry": round(curr_close, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{rr}",
                "pattern_stage": "Low Liquidity Swept (Spring / Stop Hunt)",
                "rationale": f"Sell-side liquidity swept! Price plunged to {curr_low:.2f} triggering retail stop-losses below {prev_swing_low:.2f}, then snapped back with {lower_wick/candle_range*100:.0f}% lower wick. Institutional absorption confirmed.",
                "key_levels": {"swept_low": prev_swing_low, "sweep_extreme": curr_low, "stop_loss": sl}
            }
        return None

    # =========================================================================
    # 4. POWER OF 3 (AMD) - ACCUMULATION, MANIPULATION, DISTRIBUTION
    # =========================================================================
    def _detect_power_of_3(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # Phase 1: Range accumulation in candles -15 to -5
        # Phase 2: False breakout (Manipulation) in candle -4 to -2
        # Phase 3: Real distribution in candles -1
        highs = df['High'].values
        lows = df['Low'].values
        closes = df['Close'].values

        acc_high = float(np.max(highs[-15:-5]))
        acc_low = float(np.min(lows[-15:-5]))
        range_span = acc_high - acc_low

        if range_span <= atr * 2.0:  # Valid tight accumulation range
            # Check for Manipulation above range followed by Distribution down
            manip_high = float(np.max(highs[-5:-1]))
            if manip_high > acc_high and closes[-1] < acc_high:
                sl = round(manip_high + (atr * 0.2), 2)
                tgt = round(acc_low - (range_span * 0.8), 2)
                rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
                return {
                    "strategy_id": 4,
                    "strategy_name": "The Power of 3 (AMD)",
                    "strategy_badge": "Accumulation-Manipulation-Distribution",
                    "symbol": symbol,
                    "action": "BUY PUT / DISTRIBUTION PHASE",
                    "direction": "BEARISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{rr}",
                    "pattern_stage": "Phase 3: Real Distribution Move",
                    "rationale": f"Power of 3 (AMD) active! Phase 1 Accumulation ({acc_low:.2f}-{acc_high:.2f}) -> Phase 2 Manipulation fakeout to {manip_high:.2f} -> Now entering Phase 3 Distribution dumping downwards.",
                    "key_levels": {"range_high": acc_high, "manipulation_peak": manip_high, "distribution_target": tgt}
                }

            # Check for Manipulation below range followed by Distribution up
            manip_low = float(np.min(lows[-5:-1]))
            if manip_low < acc_low and closes[-1] > acc_low:
                sl = round(manip_low - (atr * 0.2), 2)
                tgt = round(acc_high + (range_span * 0.8), 2)
                rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
                return {
                    "strategy_id": 4,
                    "strategy_name": "The Power of 3 (AMD)",
                    "strategy_badge": "Accumulation-Manipulation-Distribution",
                    "symbol": symbol,
                    "action": "BUY CALL / DISTRIBUTION PHASE",
                    "direction": "BULLISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{rr}",
                    "pattern_stage": "Phase 3: Real Distribution Expansion",
                    "rationale": f"Power of 3 (AMD) active! Phase 1 Accumulation ({acc_low:.2f}-{acc_high:.2f}) -> Phase 2 Manipulation fakeout low {manip_low:.2f} -> Now entering Phase 3 Distribution rallying upwards.",
                    "key_levels": {"range_low": acc_low, "manipulation_trough": manip_low, "distribution_target": tgt}
                }
        return None

    # =========================================================================
    # 5. LIQUIDITY HUNT - BSL / SSL DELIVERY
    # =========================================================================
    def _detect_liquidity_hunt(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # Marks Buy-Side Liquidity (BSL above swing highs) and Sell-Side Liquidity (SSL below swing lows)
        highs = df['High'].values
        lows = df['Low'].values
        closes = df['Close'].values

        bsl_level = float(np.max(highs[-20:]))
        ssl_level = float(np.min(lows[-20:]))

        dist_to_bsl = bsl_level - ltp
        dist_to_ssl = ltp - ssl_level

        # If price is in upward expansion toward BSL
        if closes[-1] > closes[-3] and dist_to_bsl > atr * 0.8:
            sl = round(ltp - (atr * 1.2), 2)
            tgt = round(bsl_level, 2)
            rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
            if rr >= 1.4:
                return {
                    "strategy_id": 5,
                    "strategy_name": "Liquidity (BSL/SSL Target)",
                    "strategy_badge": "Targeting Buy-Side Liquidity",
                    "symbol": symbol,
                    "action": "BUY CALL / TARGET BSL",
                    "direction": "BULLISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{rr}",
                    "pattern_stage": "Expanding to External Liquidity (BSL)",
                    "rationale": f"Price swept Sell-Side Liquidity (SSL) and is now running straight for Buy-Side Liquidity (BSL @ ₹{bsl_level:.2f}) where buy-stops sit. High probability magnet move.",
                    "key_levels": {"bsl_target": bsl_level, "ssl_origin": ssl_level, "invalidation": sl}
                }

        # If price is in downward expansion toward SSL
        elif closes[-1] < closes[-3] and dist_to_ssl > atr * 0.8:
            sl = round(ltp + (atr * 1.2), 2)
            tgt = round(ssl_level, 2)
            rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
            if rr >= 1.4:
                return {
                    "strategy_id": 5,
                    "strategy_name": "Liquidity (BSL/SSL Target)",
                    "strategy_badge": "Targeting Sell-Side Liquidity",
                    "symbol": symbol,
                    "action": "BUY PUT / TARGET SSL",
                    "direction": "BEARISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{rr}",
                    "pattern_stage": "Expanding to External Liquidity (SSL)",
                    "rationale": f"Price tapped Buy-Side Liquidity (BSL) and is now hunting down Sell-Side Liquidity (SSL @ ₹{ssl_level:.2f}) where retail sell-stops cluster.",
                    "key_levels": {"ssl_target": ssl_level, "bsl_origin": bsl_level, "invalidation": sl}
                }
        return None

    # =========================================================================
    # Derived Fallback Evaluators (When indicator packet is supplied)
    # =========================================================================
    def _derive_smc_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        pivots = ind.get("pivots", {})
        r1 = pivots.get("r1", ltp * 1.01)
        s1 = pivots.get("s1", ltp * 0.99)
        pct = stock_data.get("change_pct", 0.0)
        surge = ind.get("volume_surge", 1.0)

        if pct > 0.4 and ltp > r1 and surge >= 1.2:
            sl = round(ltp - atr * 1.2, 2)
            tgt = round(ltp + atr * 2.5, 2)
            return {
                "strategy_id": 1,
                "strategy_name": "Smart Money Concept (SMC)",
                "strategy_badge": "BOS & CHoCH",
                "symbol": symbol,
                "action": "BUY CALL / LONG",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.08",
                "pattern_stage": "BOS Confirmed (Break of Structure)",
                "rationale": f"Bullish BOS confirmed above Pivot R1 (₹{r1:.2f}) on {surge:.2f}x volume surge. Smart money displacement active.",
                "key_levels": {"bos_level": r1, "idm_zone": round((ltp + sl)/2, 2), "invalidation": sl}
            }
        elif pct < -0.4 and ltp < s1 and surge >= 1.2:
            sl = round(ltp + atr * 1.2, 2)
            tgt = round(ltp - atr * 2.5, 2)
            return {
                "strategy_id": 1,
                "strategy_name": "Smart Money Concept (SMC)",
                "strategy_badge": "BOS & CHoCH",
                "symbol": symbol,
                "action": "BUY PUT / SHORT",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.08",
                "pattern_stage": "BOS Confirmed (Bearish Structure)",
                "rationale": f"Bearish BOS confirmed below Pivot S1 (₹{s1:.2f}) on {surge:.2f}x volume. Institutional breakdown initiated.",
                "key_levels": {"bos_level": s1, "idm_zone": round((ltp + sl)/2, 2), "invalidation": sl}
            }
        return None

    def _derive_ob_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        ema20 = ind.get("ema20", ltp)
        vwap = ind.get("vwap", ltp)
        pct = stock_data.get("change_pct", 0.0)

        # Bullish OB Retest: Price pulling back close to EMA20 / VWAP support after an initial rally
        if pct > 0.2 and abs(ltp - vwap) <= atr * 0.5:
            sl = round(vwap - atr * 0.8, 2)
            tgt = round(ltp + atr * 2.2, 2)
            return {
                "strategy_id": 2,
                "strategy_name": "Order Block (OB)",
                "strategy_badge": "Institutional Demand Zone",
                "symbol": symbol,
                "action": "BUY CALL / OB RETEST",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.75",
                "pattern_stage": "OB Zone Retest & Reaction",
                "rationale": f"Price retesting institutional Order Block zone at VWAP (₹{vwap:.2f}). Bullish continuation expected.",
                "key_levels": {"ob_top": round(vwap + atr*0.3, 2), "ob_bottom": round(vwap - atr*0.3, 2), "stop_loss": sl}
            }
        elif pct < -0.2 and abs(ltp - vwap) <= atr * 0.5:
            sl = round(vwap + atr * 0.8, 2)
            tgt = round(ltp - atr * 2.2, 2)
            return {
                "strategy_id": 2,
                "strategy_name": "Order Block (OB)",
                "strategy_badge": "Institutional Supply Zone",
                "symbol": symbol,
                "action": "BUY PUT / OB RETEST SHORT",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.75",
                "pattern_stage": "OB Supply Retest",
                "rationale": f"Price retesting institutional Order Block supply zone at VWAP (₹{vwap:.2f}). Rejection in progress.",
                "key_levels": {"ob_top": round(vwap + atr*0.3, 2), "ob_bottom": round(vwap - atr*0.3, 2), "stop_loss": sl}
            }
        return None

    def _derive_sweep_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        high = stock_data.get("high", ltp)
        low = stock_data.get("low", ltp)
        ind = stock_data.get("indicators", {})
        bb_upper = ind.get("bb_upper", ltp)
        bb_lower = ind.get("bb_lower", ltp)
        rsi = ind.get("rsi", 50.0)

        # High sweep: High pierced Bollinger Band, but LTP pulled back inside with high RSI divergence
        if high >= bb_upper and ltp < bb_upper and rsi >= 68:
            sl = round(high + atr * 0.2, 2)
            tgt = round(ltp - atr * 2.2, 2)
            return {
                "strategy_id": 3,
                "strategy_name": "Sweep Entry",
                "strategy_badge": "Liquidity Sweep & Reversal",
                "symbol": symbol,
                "action": "BUY PUT / SWEEP REVERSAL",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.20",
                "pattern_stage": "High Liquidity Swept (Judas Wick)",
                "rationale": f"High liquidity sweep confirmed at ₹{high:.2f}. Price breached Upper Band, grabbed retail buy-stops, and rejected back down.",
                "key_levels": {"swept_high": high, "invalidation": sl}
            }
        # Low sweep: Low pierced Lower Band, but LTP snapped back up with low RSI
        elif low <= bb_lower and ltp > bb_lower and rsi <= 32:
            sl = round(low - atr * 0.2, 2)
            tgt = round(ltp + atr * 2.2, 2)
            return {
                "strategy_id": 3,
                "strategy_name": "Sweep Entry",
                "strategy_badge": "Liquidity Sweep & Reversal",
                "symbol": symbol,
                "action": "BUY CALL / SWEEP BOUNCE",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.20",
                "pattern_stage": "Low Liquidity Swept (Spring / Stop Hunt)",
                "rationale": f"Low liquidity sweep confirmed at ₹{low:.2f}. Price hunted sell-stops below Lower Band and snapped back up.",
                "key_levels": {"swept_low": low, "invalidation": sl}
            }
        return None

    def _derive_amd_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        bb_width = ind.get("bb_width", 2.0)
        pct = stock_data.get("change_pct", 0.0)
        surge = ind.get("volume_surge", 1.0)

        # Low BB width means tight accumulation phase; sudden volume spike marks manipulation/distribution transition
        if bb_width < 3.5 and surge >= 1.5:
            if pct > 0:
                sl = round(ltp - atr * 1.0, 2)
                tgt = round(ltp + atr * 2.4, 2)
                return {
                    "strategy_id": 4,
                    "strategy_name": "The Power of 3 (AMD)",
                    "strategy_badge": "Accumulation-Manipulation-Distribution",
                    "symbol": symbol,
                    "action": "BUY CALL / DISTRIBUTION EXPANSION",
                    "direction": "BULLISH",
                    "entry": ltp,
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": "1:2.40",
                    "pattern_stage": "Phase 3: Real Distribution Move",
                    "rationale": f"Power of 3 (AMD) breakout from tight accumulation band ({bb_width:.1f}% bandwidth). Phase 3 Distribution rally active on {surge:.2f}x volume.",
                    "key_levels": {"invalidation": sl, "target": tgt}
                }
            else:
                sl = round(ltp + atr * 1.0, 2)
                tgt = round(ltp - atr * 2.4, 2)
                return {
                    "strategy_id": 4,
                    "strategy_name": "The Power of 3 (AMD)",
                    "strategy_badge": "Accumulation-Manipulation-Distribution",
                    "symbol": symbol,
                    "action": "BUY PUT / DISTRIBUTION DUMP",
                    "direction": "BEARISH",
                    "entry": ltp,
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": "1:2.40",
                    "pattern_stage": "Phase 3: Real Distribution Move",
                    "rationale": f"Power of 3 (AMD) breakdown from accumulation range. Phase 3 Distribution dump active on {surge:.2f}x volume.",
                    "key_levels": {"invalidation": sl, "target": tgt}
                }
        return None

    def _derive_liquidity_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        pivots = ind.get("pivots", {})
        r2 = pivots.get("r2", ltp * 1.02)
        s2 = pivots.get("s2", ltp * 0.98)
        pct = stock_data.get("change_pct", 0.0)

        if pct > 0.3:
            sl = round(ltp - atr * 1.1, 2)
            tgt = round(r2, 2)
            rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
            return {
                "strategy_id": 5,
                "strategy_name": "Liquidity (BSL/SSL Target)",
                "strategy_badge": "Targeting Buy-Side Liquidity (BSL)",
                "symbol": symbol,
                "action": "BUY CALL / TARGET BSL",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{max(1.5, rr):.2f}",
                "pattern_stage": "Expanding to External Liquidity (BSL)",
                "rationale": f"Price is expanding towards Buy-Side Liquidity (BSL) target at Pivot R2 (₹{r2:.2f}). Liquidity pool magnet active.",
                "key_levels": {"bsl_target": r2, "invalidation": sl}
            }
        elif pct < -0.3:
            sl = round(ltp + atr * 1.1, 2)
            tgt = round(s2, 2)
            rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
            return {
                "strategy_id": 5,
                "strategy_name": "Liquidity (BSL/SSL Target)",
                "strategy_badge": "Targeting Sell-Side Liquidity (SSL)",
                "symbol": symbol,
                "action": "BUY PUT / TARGET SSL",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": f"1:{max(1.5, rr):.2f}",
                "pattern_stage": "Expanding to External Liquidity (SSL)",
                "rationale": f"Price is expanding towards Sell-Side Liquidity (SSL) target at Pivot S2 (₹{s2:.2f}). Liquidity pool magnet active.",
                "key_levels": {"ssl_target": s2, "invalidation": sl}
            }
        return None

    # =========================================================================
    # 6. FAIR VALUE GAP (FVG / IMBALANCE) STRATEGY
    # =========================================================================
    def _detect_fvg(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # 3-candle imbalance detection
        highs = df['High'].values
        lows = df['Low'].values
        closes = df['Close'].values
        n = len(df)

        for i in range(n - 2, max(2, n - 8), -1):
            # Bullish FVG: Candle i-2 High < Candle i Low (Gap between i-2 and i)
            if lows[i] > highs[i-2] and (lows[i] - highs[i-2]) > atr * 0.3:
                fvg_bottom = float(highs[i-2])
                fvg_top = float(lows[i])
                # Current price testing this FVG zone
                if fvg_bottom * 0.998 <= ltp <= fvg_top * 1.005:
                    sl = round(fvg_bottom - (atr * 0.2), 2)
                    tgt = round(ltp + ((ltp - sl) * 3.0), 2)
                    rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
                    return {
                        "strategy_id": 6,
                        "strategy_name": "Fair Value Gap (FVG)",
                        "strategy_badge": "Institutional Imbalance Tap",
                        "symbol": symbol,
                        "action": "BUY CALL / FVG BOUNCE",
                        "direction": "BULLISH",
                        "entry": round(ltp, 2),
                        "stop_loss": sl,
                        "target": tgt,
                        "risk_reward": f"1:{rr:.1f}",
                        "pattern_stage": "FVG Imbalance Mitigated & Rejecting",
                        "rationale": f"High probability Bullish Fair Value Gap (FVG) retest at ₹{fvg_bottom:.2f} - ₹{fvg_top:.2f}. Super tight SL below gap with 1:3.0 Risk:Reward target.",
                        "key_levels": {"fvg_top": fvg_top, "fvg_bottom": fvg_bottom, "invalidation": sl}
                    }

            # Bearish FVG: Candle i-2 Low > Candle i High (Gap between i-2 and i)
            elif highs[i] < lows[i-2] and (lows[i-2] - highs[i]) > atr * 0.3:
                fvg_top = float(lows[i-2])
                fvg_bottom = float(highs[i])
                # Current price testing this Bearish FVG zone
                if fvg_bottom * 0.995 <= ltp <= fvg_top * 1.002:
                    sl = round(fvg_top + (atr * 0.2), 2)
                    tgt = round(ltp - ((sl - ltp) * 3.0), 2)
                    rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
                    return {
                        "strategy_id": 6,
                        "strategy_name": "Fair Value Gap (FVG)",
                        "strategy_badge": "Supply Imbalance Tap",
                        "symbol": symbol,
                        "action": "BUY PUT / FVG REJECTION",
                        "direction": "BEARISH",
                        "entry": round(ltp, 2),
                        "stop_loss": sl,
                        "target": tgt,
                        "risk_reward": f"1:{rr:.1f}",
                        "pattern_stage": "Bearish FVG Mitigated & Rejecting",
                        "rationale": f"High probability Bearish Fair Value Gap (FVG) retest at ₹{fvg_bottom:.2f} - ₹{fvg_top:.2f}. Institutional selling imbalance rejection.",
                        "key_levels": {"fvg_top": fvg_top, "fvg_bottom": fvg_bottom, "invalidation": sl}
                    }
        return None

    def _derive_fvg_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        ema9 = ind.get("ema9", ltp)
        pct = stock_data.get("change_pct", 0.0)
        surge = ind.get("volume_surge", 1.0)

        if pct > 0.3 and abs(ltp - ema9) <= atr * 0.4 and surge >= 1.2:
            sl = round(ltp - atr * 0.8, 2)
            tgt = round(ltp + atr * 2.8, 2)
            return {
                "strategy_id": 6,
                "strategy_name": "Fair Value Gap (FVG)",
                "strategy_badge": "Institutional Imbalance Tap",
                "symbol": symbol,
                "action": "BUY CALL / FVG BOUNCE",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:3.0",
                "pattern_stage": "FVG Imbalance Mitigated",
                "rationale": f"Price tapping into Bullish Fair Value Gap (FVG) near 9 EMA (₹{ema9:.2f}). Imbalance filled, ready for rapid continuation.",
                "key_levels": {"invalidation": sl}
            }
        elif pct < -0.3 and abs(ltp - ema9) <= atr * 0.4 and surge >= 1.2:
            sl = round(ltp + atr * 0.8, 2)
            tgt = round(ltp - atr * 2.8, 2)
            return {
                "strategy_id": 6,
                "strategy_name": "Fair Value Gap (FVG)",
                "strategy_badge": "Supply Imbalance Tap",
                "symbol": symbol,
                "action": "BUY PUT / FVG REJECTION",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:3.0",
                "pattern_stage": "Bearish FVG Mitigated",
                "rationale": f"Price tapping into Bearish Fair Value Gap (FVG) near 9 EMA (₹{ema9:.2f}). Supply imbalance rejection.",
                "key_levels": {"invalidation": sl}
            }
        return None

    # =========================================================================
    # 7. NARROW CPR TREND BLAST STRATEGY (DALAL STREET SPECIAL)
    # =========================================================================
    def _detect_cpr_blast(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float) -> Optional[Dict[str, Any]]:
        # Calculate Classical Central Pivot Range (CPR)
        highs = df['High'].values
        lows = df['Low'].values
        closes = df['Close'].values

        recent_high = float(np.max(highs[-20:-1]))
        recent_low = float(np.min(lows[-20:-1]))
        recent_close = float(closes[-2])

        pivot = (recent_high + recent_low + recent_close) / 3.0
        bc = (recent_high + recent_low) / 2.0
        tc = (2.0 * pivot) - bc
        cpr_top = max(tc, bc)
        cpr_bottom = min(tc, bc)
        cpr_width_pct = (abs(tc - bc) / (pivot + 1e-9)) * 100.0

        # Narrow CPR condition: width < 0.35%
        if cpr_width_pct <= 0.35:
            # Bullish Breakout above CPR Top
            if ltp > cpr_top:
                sl = round(cpr_bottom - (atr * 0.3), 2)
                tgt = round(ltp + (atr * 2.8), 2)
                rr = round((tgt - ltp) / max(0.1, ltp - sl), 2)
                return {
                    "strategy_id": 7,
                    "strategy_name": "Narrow CPR Trend Blast",
                    "strategy_badge": "Dalal Street Trend Blast",
                    "symbol": symbol,
                    "action": "BUY CALL / TREND BLAST",
                    "direction": "BULLISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{max(1.8, rr):.1f}",
                    "pattern_stage": "Narrow CPR Breakout (Trending Day Trigger)",
                    "rationale": f"Super Narrow CPR ({cpr_width_pct:.2f}% width) breakout! Price broke above Top Central (₹{cpr_top:.2f}). 80%+ probability of massive 2-4% trending day.",
                    "key_levels": {"cpr_top": round(cpr_top, 2), "cpr_bottom": round(cpr_bottom, 2), "pivot": round(pivot, 2)}
                }
            # Bearish Breakdown below CPR Bottom
            elif ltp < cpr_bottom:
                sl = round(cpr_top + (atr * 0.3), 2)
                tgt = round(ltp - (atr * 2.8), 2)
                rr = round((ltp - tgt) / max(0.1, sl - ltp), 2)
                return {
                    "strategy_id": 7,
                    "strategy_name": "Narrow CPR Trend Blast",
                    "strategy_badge": "Dalal Street Trend Blast",
                    "symbol": symbol,
                    "action": "BUY PUT / TREND DUMP",
                    "direction": "BEARISH",
                    "entry": round(ltp, 2),
                    "stop_loss": sl,
                    "target": tgt,
                    "risk_reward": f"1:{max(1.8, rr):.1f}",
                    "pattern_stage": "Narrow CPR Breakdown (Trending Dump Trigger)",
                    "rationale": f"Super Narrow CPR ({cpr_width_pct:.2f}% width) breakdown! Price plunged below Bottom Central (₹{cpr_bottom:.2f}). High velocity trend dump initiated.",
                    "key_levels": {"cpr_top": round(cpr_top, 2), "cpr_bottom": round(cpr_bottom, 2), "pivot": round(pivot, 2)}
                }
        return None

    def _derive_cpr_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        ltp = stock_data.get("ltp", 0.0)
        ind = stock_data.get("indicators", {})
        pivots = ind.get("pivots", {})
        pivot = pivots.get("pivot", ltp)
        r1 = pivots.get("r1", ltp * 1.01)
        s1 = pivots.get("s1", ltp * 0.99)
        pct = stock_data.get("change_pct", 0.0)

        if pct > 0.4 and ltp > r1:
            sl = round(pivot, 2)
            tgt = round(ltp + atr * 2.6, 2)
            return {
                "strategy_id": 7,
                "strategy_name": "Narrow CPR Trend Blast",
                "strategy_badge": "Dalal Street Trend Blast",
                "symbol": symbol,
                "action": "BUY CALL / TREND BLAST",
                "direction": "BULLISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.5",
                "pattern_stage": "CPR Range Expansion",
                "rationale": f"Narrow CPR Range Expansion above Pivot R1 (₹{r1:.2f}). Dalal Street trend blast in progress.",
                "key_levels": {"pivot": pivot}
            }
        elif pct < -0.4 and ltp < s1:
            sl = round(pivot, 2)
            tgt = round(ltp - atr * 2.6, 2)
            return {
                "strategy_id": 7,
                "strategy_name": "Narrow CPR Trend Blast",
                "strategy_badge": "Dalal Street Trend Blast",
                "symbol": symbol,
                "action": "BUY PUT / TREND DUMP",
                "direction": "BEARISH",
                "entry": ltp,
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:2.5",
                "pattern_stage": "CPR Breakdown Dump",
                "rationale": f"Narrow CPR Breakdown Dump below Pivot S1 (₹{s1:.2f}). Heavy institutional distribution.",
                "key_levels": {"pivot": pivot}
            }
        return None

    # =========================================================================
    # 8. OPTION SELLER TRAP / GAMMA BLAST STRATEGY
    # =========================================================================
    def _detect_gamma_blast(self, symbol: str, ltp: float, df: pd.DataFrame, atr: float, stock_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        fno = stock_data.get("fno", {})
        pcr = fno.get("pcr", 1.0)
        atm = fno.get("atm_strike", round(ltp))
        surge = stock_data.get("indicators", {}).get("volume_surge", 1.0)
        pct = stock_data.get("change_pct", 0.0)

        # Gamma blast long: PCR > 1.15 + Volume Surge > 1.4 + Price pushing up
        if pct > 0.35 and surge >= 1.4 and pcr >= 1.15:
            sl = round(ltp - atr * 0.9, 2)
            tgt = round(ltp + atr * 3.2, 2)
            return {
                "strategy_id": 8,
                "strategy_name": "Option Seller Trap / Gamma Blast",
                "strategy_badge": "Call Sellers Trapped (Short Covering)",
                "symbol": symbol,
                "action": "BUY CALL / GAMMA BLAST",
                "direction": "BULLISH",
                "entry": round(ltp, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:3.5",
                "pattern_stage": "Call Writers Short-Covering Squeeze",
                "rationale": f"Option Seller Trap confirmed! Heavy call writers trapped at strike {atm} CE with PCR {pcr:.2f}. Volume {surge:.2f}x average. Expecting 2x-3x gamma premium blast.",
                "key_levels": {"trapped_strike": f"{atm} CE", "invalidation": sl}
            }
        # Gamma blast short: PCR < 0.80 + Volume Surge > 1.4 + Price dropping
        elif pct < -0.35 and surge >= 1.4 and pcr <= 0.80:
            sl = round(ltp + atr * 0.9, 2)
            tgt = round(ltp - atr * 3.2, 2)
            return {
                "strategy_id": 8,
                "strategy_name": "Option Seller Trap / Gamma Blast",
                "strategy_badge": "Put Sellers Trapped (Long Liquidation)",
                "symbol": symbol,
                "action": "BUY PUT / GAMMA BLAST",
                "direction": "BEARISH",
                "entry": round(ltp, 2),
                "stop_loss": sl,
                "target": tgt,
                "risk_reward": "1:3.5",
                "pattern_stage": "Put Writers Panic Unwinding Squeeze",
                "rationale": f"Option Seller Trap confirmed! Put writers trapped at strike {atm} PE with weak PCR {pcr:.2f}. Volume {surge:.2f}x average. Expecting aggressive option premium explosion.",
                "key_levels": {"trapped_strike": f"{atm} PE", "invalidation": sl}
            }
        return None

    def _derive_gamma_from_indicators(self, symbol: str, stock_data: Dict[str, Any], atr: float) -> Optional[Dict[str, Any]]:
        return self._detect_gamma_blast(symbol, stock_data.get("ltp", 0.0), None, atr, stock_data)
