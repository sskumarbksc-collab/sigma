import urllib.request
import json

base = 'https://sigma-1-swg4.onrender.com'

try:
    with urllib.request.urlopen(f'{base}/api/status', timeout=15) as r:
        print('STATUS:', json.loads(r.read()))
except Exception as e:
    print('STATUS ERROR:', e)

try:
    with urllib.request.urlopen(f'{base}/api/smc-strategies', timeout=15) as r:
        data = json.loads(r.read())
        print('SMC STRATEGIES LAST SCAN:', data.get('last_scan'))
        strats = data.get('strategies', {})
        for k, v in strats.items():
            print(f'  {k}: {len(v.get("setups", []))} setups')
except Exception as e:
    print('SMC ERROR:', e)

try:
    with urllib.request.urlopen(f'{base}/api/setups', timeout=15) as r:
        data = json.loads(r.read())
        print('SETUPS COUNT:', data.get('count'))
        for s in data.get('setups', [])[:5]:
            print('  Sample:', s.get('symbol'), 'LTP:', s.get('ltp'), 'Action:', s.get('action'))
except Exception as e:
    print('SETUPS ERROR:', e)
