import asyncio
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from config import DEFAULT_WATCHLIST, MIN_CONSENSUS_THRESHOLD
from data_feed import NSEDataFeed
from smc_engine import SMCStrategyEngine
from agents import (
    MarketBreadthAgent, VolumeSurgeAgent, DerivativesOIAgent,
    TrendStructureAgent, BreakoutHunterAgent, MomentumOscillatorAgent, SupplyDemandZonesAgent,
    NewsCatalystAgent, GlobalCuesVixAgent, InstitutionalFlowAgent,
    IntradayScalpAgent, FnoSwingAgent, RiskManagementAgent,
    MasterArbiterAgent, AlertDispatcherAgent
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TradingEngine")

class TradingEngine:
    """
    15-AI-Agent Trading Orchestrator & 5-SMC-Strategy Detection Hub.
    Coordinates continuous market scanning, 15 agent consensus evaluations,
    and classifies stocks into the 5 distinct institutional strategies:
      1. Smart Money Concept (SMC - BOS/CHoCH)
      2. Order Block (OB Institutional Retest)
      3. Sweep Entry (Liquidity Grab & Reversal)
      4. Power of 3 (AMD - Accumulation, Manipulation, Distribution)
      5. Liquidity Hunt (BSL / SSL Delivery)
    """

    def __init__(self):
        self.data_feed = NSEDataFeed()
        self.smc_engine = SMCStrategyEngine()
        self.watchlist = list(DEFAULT_WATCHLIST)
        self.is_scanning = False
        self.auto_scan_active = False
        self.scan_interval = 60  # seconds

        # Initialize the 15 Autonomous Agents
        self.agent1 = MarketBreadthAgent()
        self.agent2 = VolumeSurgeAgent()
        self.agent3 = DerivativesOIAgent()
        self.agent4 = TrendStructureAgent()
        self.agent5 = BreakoutHunterAgent()
        self.agent6 = MomentumOscillatorAgent()
        self.agent7 = SupplyDemandZonesAgent()
        self.agent8 = NewsCatalystAgent()
        self.agent9 = GlobalCuesVixAgent()
        self.agent10 = InstitutionalFlowAgent()
        self.agent11 = IntradayScalpAgent()
        self.agent12 = FnoSwingAgent()
        self.agent13 = RiskManagementAgent()
        self.agent14 = MasterArbiterAgent(min_consensus=MIN_CONSENSUS_THRESHOLD)
        self.agent15 = AlertDispatcherAgent()

        self.agents = [
            self.agent1, self.agent2, self.agent3,
            self.agent4, self.agent5, self.agent6, self.agent7,
            self.agent8, self.agent9, self.agent10,
            self.agent11, self.agent12, self.agent13,
            self.agent14, self.agent15
        ]

        # In-memory storage for dashboard
        self.active_setups: List[Dict[str, Any]] = []
        self.market_pulse: Dict[str, Any] = {}
        self.last_scan_time: Optional[str] = None
        self.scan_logs: List[str] = []

        # 5 Separate SMC Strategy Setups
        self.smc_strategy_setups = {
            "strategy_1_smc": [],
            "strategy_2_order_block": [],
            "strategy_3_sweep_entry": [],
            "strategy_4_power_of_3": [],
            "strategy_5_liquidity_hunt": []
        }

    def get_agent_states(self) -> List[Dict[str, Any]]:
        """Returns the real-time state, role, and last verdict of all 15 agents."""
        states = []
        for a in self.agents:
            states.append({
                "agent_id": a.agent_id,
                "name": a.name,
                "role": a.role,
                "layer": a.layer,
                "description": a.description,
                "status": a.status,
                "last_verdict": a.last_verdict.to_dict() if a.last_verdict else None
            })
        return states

    def scan_single_symbol(self, symbol: str, market_pulse: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Runs a single stock through both the 15-agent committee pipeline
        and the 5 SMC Institutional Strategy detectors.
        """
        stock_data = self.data_feed.get_stock_data(symbol)
        if not stock_data:
            return None

        # 1. Run 15-Agent Committee Analysis (Agents 1 through 13)
        v1 = self.agent1.evaluate(stock_data, market_pulse)
        v2 = self.agent2.evaluate(stock_data, market_pulse)
        v3 = self.agent3.evaluate(stock_data, market_pulse)
        v4 = self.agent4.evaluate(stock_data, market_pulse)
        v5 = self.agent5.evaluate(stock_data, market_pulse)
        v6 = self.agent6.evaluate(stock_data, market_pulse)
        v7 = self.agent7.evaluate(stock_data, market_pulse)
        v8 = self.agent8.evaluate(stock_data, market_pulse)
        v9 = self.agent9.evaluate(stock_data, market_pulse)
        v10 = self.agent10.evaluate(stock_data, market_pulse)
        v11 = self.agent11.evaluate(stock_data, market_pulse)
        v12 = self.agent12.evaluate(stock_data, market_pulse)
        v13 = self.agent13.evaluate(stock_data, market_pulse)

        committee_verdicts = [v1, v2, v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13]

        # 2. Agent 14: Master Decision Arbiter computes institutional consensus
        v14 = self.agent14.arbitrate(stock_data, committee_verdicts)

        # 3. Agent 15: Alert Dispatcher formats complete trade ticket
        all_verdicts = committee_verdicts + [v14]
        ticket = self.agent15.format_trade_ticket(
            stock_data=stock_data,
            arbiter_verdict=v14,
            risk_verdict=v13,
            fno_verdict=v12,
            all_verdicts=all_verdicts
        )

        # 4. Run 5 SMC Institutional Strategy Detectors
        raw_df = stock_data.get("raw_df")
        smc_results = self.smc_engine.analyze_all_strategies(stock_data, raw_df=raw_df)
        ticket["smc_strategies"] = smc_results

        # Add to the 5 individual strategy buckets if active
        for strat_key, strat_val in smc_results.items():
            if strat_val:
                # Attach extra ticket info
                strat_val["ticket_id"] = ticket["ticket_id"]
                strat_val["ltp"] = stock_data["ltp"]
                strat_val["change_pct"] = stock_data["change_pct"]
                strat_val["consensus_pct"] = ticket["consensus_pct"]
                strat_val["timestamp"] = ticket["timestamp"]
                self.smc_strategy_setups[strat_key].append(strat_val)

        return ticket

    def run_full_scan(self) -> Dict[str, Any]:
        """
        Performs a full sweep across all symbols in the watchlist.
        """
        self.is_scanning = True
        start_time = datetime.now()
        timestamp_str = start_time.strftime("%H:%M:%S")
        self.scan_logs.append(f"[{timestamp_str}] Commenced sweep across {len(self.watchlist)} symbols for 15 Agents & 5 SMC Strategies...")

        # Reset 5 Strategy buckets
        self.smc_strategy_setups = {
            "strategy_1_smc": [],
            "strategy_2_order_block": [],
            "strategy_3_sweep_entry": [],
            "strategy_4_power_of_3": [],
            "strategy_5_liquidity_hunt": []
        }

        # Refresh macro pulse
        self.market_pulse = self.data_feed.get_market_pulse()

        new_setups = []
        for symbol in self.watchlist:
            try:
                ticket = self.scan_single_symbol(symbol, self.market_pulse)
                if ticket:
                    new_setups.append(ticket)
            except Exception as e:
                logger.error(f"Error scanning {symbol}: {e}")

        # Sort setups: Approved high consensus setups first
        new_setups.sort(key=lambda x: (x["status"] == "APPROVED", x["consensus_pct"]), reverse=True)
        self.active_setups = new_setups
        self.last_scan_time = datetime.now().strftime("%H:%M:%S")
        self.is_scanning = False

        approved_count = sum(1 for s in new_setups if s["status"] == "APPROVED")
        total_smc = sum(len(v) for v in self.smc_strategy_setups.values())
        self.scan_logs.append(f"[{self.last_scan_time}] Sweep complete. {approved_count} 15-Agent setups approved. {total_smc} setups found across 5 SMC strategies.")

        if len(self.scan_logs) > 50:
            self.scan_logs = self.scan_logs[-50:]

        return {
            "timestamp": self.last_scan_time,
            "symbols_scanned": len(self.watchlist),
            "approved_setups": approved_count,
            "setups": self.active_setups,
            "smc_strategies": self.smc_strategy_setups,
            "market_pulse": self.market_pulse
        }

    def get_smc_strategy_setups(self) -> Dict[str, Any]:
        """Returns the classified setups categorized by the 5 SMC strategies."""
        return {
            "last_scan": self.last_scan_time,
            "strategies": {
                "strategy_1_smc": {
                    "id": 1,
                    "title": "Smart Money Concept (SMC)",
                    "subtitle": "BOS (Break of Structure) & CHoCH (Change of Character)",
                    "description": "Smart Money displacement setups: Breaks of key structure after liquidity inducement (IDM).",
                    "count": len(self.smc_strategy_setups["strategy_1_smc"]),
                    "setups": self.smc_strategy_setups["strategy_1_smc"]
                },
                "strategy_2_order_block": {
                    "id": 2,
                    "title": "Order Block (OB)",
                    "subtitle": "Institutional Supply & Demand Zones",
                    "description": "Last opposite candle before strong displacement. Signals on retest and price rejection.",
                    "count": len(self.smc_strategy_setups["strategy_2_order_block"]),
                    "setups": self.smc_strategy_setups["strategy_2_order_block"]
                },
                "strategy_3_sweep_entry": {
                    "id": 3,
                    "title": "Sweep Entry (Liquidity Sweep)",
                    "subtitle": "Stop Hunt & Rapid Reversal",
                    "description": "Price spikes past previous swing high/low to grab stop liquidity, leaving a long rejection wick.",
                    "count": len(self.smc_strategy_setups["strategy_3_sweep_entry"]),
                    "setups": self.smc_strategy_setups["strategy_3_sweep_entry"]
                },
                "strategy_4_power_of_3": {
                    "id": 4,
                    "title": "The Power of 3 (AMD)",
                    "subtitle": "Accumulation - Manipulation - Distribution",
                    "description": "Range consolidation followed by false breakout (Judas swing) and strong real distribution in opposite direction.",
                    "count": len(self.smc_strategy_setups["strategy_4_power_of_3"]),
                    "setups": self.smc_strategy_setups["strategy_4_power_of_3"]
                },
                "strategy_5_liquidity_hunt": {
                    "id": 5,
                    "title": "Liquidity (BSL / SSL Delivery)",
                    "subtitle": "Targeting Buy-Side / Sell-Side Liquidity Pools",
                    "description": "Price expands toward major resting stop pools (BSL above swing highs, SSL below swing lows).",
                    "count": len(self.smc_strategy_setups["strategy_5_liquidity_hunt"]),
                    "setups": self.smc_strategy_setups["strategy_5_liquidity_hunt"]
                }
            }
        }

    async def background_scan_loop(self):
        """Asynchronous continuous background scanner"""
        self.auto_scan_active = True
        logger.info("Auto-scan background loop activated.")
        while self.auto_scan_active:
            try:
                await asyncio.to_thread(self.run_full_scan)
            except Exception as e:
                logger.error(f"Error in background scan loop: {e}")
            await asyncio.sleep(self.scan_interval)
