import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Default Watchlist: Liquid Intraday & F&O stocks + Major Indices
DEFAULT_WATCHLIST = [
    "^NSEI",          # NIFTY 50
    "^NSEBANK",       # BANK NIFTY
    "RELIANCE.NS",    # Reliance Industries
    "HDFCBANK.NS",    # HDFC Bank
    "ICICIBANK.NS",   # ICICI Bank
    "INFY.NS",        # Infosys
    "TCS.NS",         # TCS
    "SBIN.NS",        # State Bank of India
    "TATASTEEL.NS",   # Tata Steel
    "BAJFINANCE.NS",  # Bajaj Finance
    "AXISBANK.NS",    # Axis Bank
    "KOTAKBANK.NS",   # Kotak Mahindra Bank
    "LT.NS",          # Larsen & Toubro
    "BHARTIARTL.NS",  # Bharti Airtel
    "ITC.NS"          # ITC
]

# Consensus threshold for a setup to be approved by Agent 14 (Master Arbiter)
# Minimum 70% consensus required (e.g. at least 11 of 15 agents agreeing)
MIN_CONSENSUS_THRESHOLD = 0.70

# Scan interval in seconds
DEFAULT_SCAN_INTERVAL = 60

# Upstox API Configuration (Can be updated via UI or environment)
UPSTOX_CONFIG = {
    "api_key": os.getenv("UPSTOX_API_KEY", ""),
    "api_secret": os.getenv("UPSTOX_API_SECRET", ""),
    "redirect_uri": os.getenv("UPSTOX_REDIRECT_URI", "http://localhost:8000/api/upstox/callback"),
    "access_token": os.getenv("UPSTOX_ACCESS_TOKEN", "")
}
